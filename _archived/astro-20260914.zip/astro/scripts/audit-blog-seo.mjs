/**
 * Blog SEO content audit — fails CI when editorial rules are broken.
 * Run: node scripts/audit-blog-seo.mjs
 *
 * Rules (warn vs fail):
 *  - FAIL: stub/placeholder content, missing H2, missing outboundRefs metadata,
 *          missing featuredImage, missing focusKeyword
 *  - WARN: word count < 1200, keyword not in first 100 words, no body internal links
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const posts = JSON.parse(
	fs.readFileSync(path.join(__dirname, '../src/data/blog-posts.json'), 'utf8')
);

function stripHtml(html) {
	return html
		.replace(/<script[\s\S]*?<\/script>/gi, ' ')
		.replace(/<style[\s\S]*?<\/style>/gi, ' ')
		.replace(/<[^>]+>/g, ' ')
		.replace(/&nbsp;/g, ' ')
		.replace(/&amp;/g, '&')
		.replace(/\s+/g, ' ')
		.trim();
}

function words(text) {
	return text.split(/\s+/).filter(Boolean);
}

const fails = [];
const warns = [];

for (const post of posts) {
	const html = post.contentHtml || '';
	const text = stripHtml(html);
	const wordList = words(text);
	const wordCount = wordList.length;
	const first100 = wordList.slice(0, 100).join(' ').toLowerCase();
	const kw = (post.focusKeyword || '').toLowerCase().trim();
	const kwInFirst100 = kw ? first100.includes(kw) : false;
	const kwPartial =
		kw &&
		kw
			.split(/\s+/)
			.filter((t) => t.length > 3)
			.every((t) => first100.includes(t));
	const internal = (html.match(/href=["'](\/[^"']+)["']/g) || []).length;
	const h2 = (html.match(/<h2\b/gi) || []).length;
	const h3 = (html.match(/<h3\b/gi) || []).length;
	const stub = /Full article content is available on the live WordPress/i.test(html) || wordCount < 150;
	const label = post.slug;

	if (stub) fails.push(`${label}: stub or extremely thin content (${wordCount} words)`);
	if (!post.focusKeyword) fails.push(`${label}: missing focusKeyword`);
	if (!post.featuredImage) fails.push(`${label}: missing featuredImage`);
	if (!post.outboundRefs?.length) fails.push(`${label}: missing outboundRefs`);
	if (h2 < 1) fails.push(`${label}: no H2 headings`);

	if (wordCount < 1200) warns.push(`${label}: ${wordCount} words (target ≥1200)`);
	if (!kwInFirst100 && !kwPartial) warns.push(`${label}: focus keyword weak/missing in first 100 words`);
	if (internal < 1) warns.push(`${label}: no internal body links`);
	if (h3 < 1) warns.push(`${label}: no H3 subsections (flat H2-only outline)`);

	console.log(
		[
			wordCount.toString().padStart(4),
			`h2=${h2}`,
			`h3=${h3}`,
			`in=${internal}`,
			`out=${post.outboundRefs?.length ?? 0}`,
			`img=${post.featuredImage || '-'}`,
			label,
		].join('  ')
	);
}

console.log('\n---');
if (warns.length) {
	console.log(`WARNINGS (${warns.length}):`);
	warns.forEach((w) => console.log('  ·', w));
}
if (fails.length) {
	console.log(`FAILURES (${fails.length}):`);
	fails.forEach((f) => console.log('  ·', f));
	process.exit(1);
}

console.log(`OK — ${posts.length} posts passed hard SEO gates (${warns.length} soft warnings).`);
