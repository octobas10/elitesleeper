<?php
/**
 * One-shot exporter: WP article PHP sources → Astro blog HTML fragments.
 * Run: php scripts/export-blog-from-wp.php
 * Writes: scripts/.cache/blog-export.json
 */

declare(strict_types=1);

define('ABSPATH', __DIR__);

function esc_html(string $text): string {
	return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function esc_attr(string $text): string {
	return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function esc_url(string $url): string {
	return htmlspecialchars($url, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function wp_kses_post(string $html): string {
	return $html;
}

function wp_json_encode($data): string {
	return json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

function hlm_serialize_block(array $block): string {
	$name = (string) ($block['blockName'] ?? '');
	$attrs = $block['attrs'] ?? array();
	$inner = (string) ($block['innerHTML'] ?? '');

	if ($name === 'core/heading' || $name === 'core/paragraph') {
		return $inner . "\n";
	}

	if (str_starts_with($name, 'hlm/')) {
		$short = substr($name, 4);
		return hlm_render_hlm_block($short, is_array($attrs) ? $attrs : array()) . "\n";
	}

	return $inner . "\n";
}

function hlm_render_hlm_block(string $block_name, array $attributes): string {
	switch ($block_name) {
		case 'article-mistake':
			$number = (string) ($attributes['number'] ?? '1');
			$title = (string) ($attributes['title'] ?? '');
			$summary = (string) ($attributes['summary'] ?? '');
			$recommendation = (string) ($attributes['recommendation'] ?? '');
			$why = (string) ($attributes['whyItMatters'] ?? '');
			$paragraphs = array_filter(array($summary, $recommendation, $why), static fn($t) => trim((string) $t) !== '');
			$html = '<article class="hlm-article-mistake"><div class="hlm-article-mistake__badge" aria-hidden="true"><span class="hlm-article-mistake__number">' . esc_html($number) . '</span></div><div class="hlm-article-mistake__body">';
			if ($title !== '') {
				$html .= '<h3 class="hlm-article-mistake__title">' . esc_html($title) . '</h3>';
			}
			foreach ($paragraphs as $p) {
				$html .= '<p class="hlm-article-mistake__text">' . esc_html((string) $p) . '</p>';
			}
			$html .= '</div></article>';
			return $html;

		case 'article-compare':
			$html = '<section class="hlm-article-compare">';
			if (!empty($attributes['headline'])) {
				$html .= '<h2 class="hlm-article-compare__headline">' . esc_html((string) $attributes['headline']) . '</h2>';
			}
			$html .= '<div class="hlm-article-compare__grid"><div class="hlm-article-compare__column hlm-article-compare__column--left">';
			if (!empty($attributes['leftTitle'])) {
				$html .= '<h3 class="hlm-article-compare__title">' . esc_html((string) $attributes['leftTitle']) . '</h3>';
			}
			foreach (($attributes['leftParagraphs'] ?? array()) as $p) {
				if (trim((string) $p) !== '') {
					$html .= '<p class="hlm-article-compare__text">' . esc_html((string) $p) . '</p>';
				}
			}
			$html .= '</div><div class="hlm-article-compare__column hlm-article-compare__column--right">';
			if (!empty($attributes['rightTitle'])) {
				$html .= '<h3 class="hlm-article-compare__title">' . esc_html((string) $attributes['rightTitle']) . '</h3>';
			}
			foreach (($attributes['rightParagraphs'] ?? array()) as $p) {
				if (trim((string) $p) !== '') {
					$html .= '<p class="hlm-article-compare__text">' . esc_html((string) $p) . '</p>';
				}
			}
			$html .= '</div></div>';
			foreach (($attributes['footnote'] ?? array()) as $p) {
				if (trim((string) $p) !== '') {
					$html .= '<p class="hlm-article-compare__footnote">' . esc_html((string) $p) . '</p>';
				}
			}
			$html .= '</section>';
			return $html;

		case 'article-checklist':
			$html = '<section class="hlm-article-checklist">';
			if (!empty($attributes['headline'])) {
				$html .= '<h2 class="hlm-article-checklist__headline">' . esc_html((string) $attributes['headline']) . '</h2>';
			}
			foreach (($attributes['paragraphs'] ?? array()) as $p) {
				if (trim((string) $p) !== '') {
					$html .= '<p class="hlm-article-checklist__intro">' . esc_html((string) $p) . '</p>';
				}
			}
			$items = $attributes['items'] ?? array();
			if (!empty($items)) {
				$html .= '<ul class="hlm-article-checklist__list">';
				foreach ($items as $item) {
					if (trim((string) $item) !== '') {
						$html .= '<li class="hlm-article-checklist__item">' . esc_html((string) $item) . '</li>';
					}
				}
				$html .= '</ul>';
			}
			foreach (($attributes['outro'] ?? array()) as $p) {
				if (trim((string) $p) !== '') {
					$html .= '<p class="hlm-article-checklist__outro">' . esc_html((string) $p) . '</p>';
				}
			}
			$html .= '</section>';
			return $html;

		case 'article-callout':
			$variant = (string) ($attributes['variant'] ?? 'help');
			if (!in_array($variant, array('help', 'cta', 'tip'), true)) {
				$variant = 'help';
			}
			$html = '<aside class="hlm-article-callout hlm-article-callout--' . esc_attr($variant) . '">';
			if (!empty($attributes['headline'])) {
				$html .= '<h2 class="hlm-article-callout__headline">' . esc_html((string) $attributes['headline']) . '</h2>';
			}
			$paragraphs = $attributes['paragraphs'] ?? array();
			if (!empty($paragraphs)) {
				$html .= '<div class="hlm-article-callout__body">';
				foreach ($paragraphs as $p) {
					if (trim((string) $p) !== '') {
						$html .= '<p>' . wp_kses_post((string) $p) . '</p>';
					}
				}
				$html .= '</div>';
			}
			$html .= '</aside>';
			return $html;
	}

	return '';
}

function hlm_article_heading(string $text, int $level = 2): string {
	$level = max(2, min(4, $level));
	$tag = 'h' . $level;
	$html = sprintf('<%1$s>%2$s</%1$s>', $tag, esc_html($text));
	return hlm_serialize_block(array(
		'blockName' => 'core/heading',
		'attrs' => array('level' => $level),
		'innerHTML' => $html,
	));
}

function hlm_article_paragraph(string $html): string {
	$content = sprintf('<p>%s</p>', wp_kses_post($html));
	return hlm_serialize_block(array(
		'blockName' => 'core/paragraph',
		'attrs' => array(),
		'innerHTML' => $content,
	));
}

function hlm_article_block(string $block_name, array $attributes): string {
	return hlm_serialize_block(array(
		'blockName' => 'hlm/' . $block_name,
		'attrs' => $attributes,
		'innerHTML' => '',
	));
}

function hlm_article_callout_markup(string $headline, array $paragraphs, string $variant = 'help'): string {
	return hlm_article_block('article-callout', array(
		'variant' => $variant,
		'headline' => $headline,
		'paragraphs' => $paragraphs,
	));
}

function hlm_article_checklist_markup(string $headline, array $paragraphs, array $items, array $outro = array()): string {
	return hlm_article_block('article-checklist', array(
		'headline' => $headline,
		'paragraphs' => $paragraphs,
		'items' => $items,
		'outro' => $outro,
	));
}

function hlm_article_compare_markup(array $args): string {
	return hlm_article_block('article-compare', $args);
}

function hlm_article_from_legacy_html(string $html): string {
	return trim($html) . "\n";
}

$theme = dirname(__DIR__, 2) . '/site/wp-content/themes/hlm-theme-kadence/inc/hlm';
require $theme . '/articles/nursing-program-content.php';
require $theme . '/articles/berkeley-college-content.php';
require $theme . '/articles/online-vs-campus-nursing-content.php';
require $theme . '/articles/fafsa-mistakes-content.php';
require $theme . '/hlm-seo-blog-content.php';

$posts = hlm_kadence_seo_blog_posts_content();
$export = array();

foreach ($posts as $slug => $data) {
	$content = (string) ($data['content'] ?? '');
	$plain = trim(preg_replace('/\s+/', ' ', strip_tags($content)) ?? '');
	$words = $plain === '' ? 0 : count(preg_split('/\s+/', $plain) ?: array());
	$export[$slug] = array(
		'excerpt' => (string) ($data['excerpt'] ?? ''),
		'focusKeyword' => (string) ($data['focus_keyword'] ?? ''),
		'seoTitle' => (string) ($data['seo_title'] ?? ''),
		'featuredImage' => (string) ($data['featured_image'] ?? 'student'),
		'contentHtml' => trim($content),
		'wordCount' => $words,
	);
}

$outDir = __DIR__ . '/.cache';
if (!is_dir($outDir)) {
	mkdir($outDir, 0775, true);
}
$outFile = $outDir . '/blog-export.json';
file_put_contents($outFile, json_encode($export, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
fwrite(STDOUT, "Wrote {$outFile} (" . count($export) . " posts)\n");
foreach ($export as $slug => $row) {
	fwrite(STDOUT, sprintf("  %4d words  %s\n", $row['wordCount'], $slug));
}
