/**
 * Merge WP-exported HTML + SEO metadata into blog-posts.json.
 * Run: node scripts/merge-blog-export.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const postsPath = path.join(root, 'src/data/blog-posts.json');
const exportPath = path.join(__dirname, '.cache/blog-export.json');

const META = {
	'how-to-choose-the-right-nursing-program': {
		featuredImage: 'student',
		outboundRefs: ['bls_nursing', 'ncsbn'],
		intent: 'informational',
	},
	'berkeley-college-application-tips-for-working-adults': {
		featuredImage: 'student',
		outboundRefs: ['berkeley_college', 'nces_adult'],
		intent: 'informational',
	},
	'online-vs-campus-nursing-programs': {
		featuredImage: 'student',
		outboundRefs: ['bls_nursing', 'nces_adult'],
		intent: 'informational',
	},
	'5-fafsa-mistakes-to-avoid': {
		featuredImage: 'student',
		outboundRefs: ['studentaid_fafsa', 'nces_adult'],
		intent: 'informational',
	},
	'what-universities-should-know-about-lead-quality': {
		featuredImage: 'university',
		outboundRefs: ['edgov_enrollment', 'mckinsey_higher_ed'],
		intent: 'commercial',
	},
	'enrollment-marketing-roi-for-universities': {
		featuredImage: 'university',
		outboundRefs: ['mckinsey_higher_ed', 'edgov_enrollment'],
		intent: 'commercial',
	},
	'how-hlm-helps-universities-fill-programs': {
		featuredImage: 'hlm',
		outboundRefs: ['edgov_enrollment', 'mckinsey_higher_ed'],
		intent: 'commercial',
	},
	'how-students-find-the-right-program-with-hlm': {
		featuredImage: 'hlm',
		outboundRefs: ['nces_adult', 'edgov_enrollment'],
		intent: 'informational',
	},
	'premium-education-lead-generation-hlm': {
		featuredImage: 'hlm',
		outboundRefs: ['mckinsey_higher_ed'],
		intent: 'commercial',
	},
	'consent-based-education-leads-hlm': {
		featuredImage: 'compliance',
		outboundRefs: ['edgov_enrollment', 'fcc_tcpa'],
		intent: 'commercial',
	},
	'student-lead-generation-universities-usa': {
		featuredImage: 'university',
		outboundRefs: ['edgov_enrollment', 'mckinsey_higher_ed'],
		intent: 'commercial',
	},
	'nursing-program-leads-for-colleges': {
		featuredImage: 'university',
		outboundRefs: ['bls_nursing', 'ncsbn'],
		intent: 'commercial',
	},
	'tcpa-compliant-education-leads': {
		featuredImage: 'compliance',
		outboundRefs: ['fcc_tcpa', 'edgov_enrollment'],
		intent: 'commercial',
	},
	'adult-learner-enrollment-marketing': {
		featuredImage: 'university',
		outboundRefs: ['nces_adult', 'mckinsey_higher_ed'],
		intent: 'commercial',
	},
	'cost-per-enrollment-vs-cost-per-lead': {
		featuredImage: 'university',
		outboundRefs: ['mckinsey_higher_ed', 'edgov_enrollment'],
		intent: 'commercial',
	},
	'how-to-buy-education-leads': {
		featuredImage: 'university',
		outboundRefs: ['fcc_tcpa', 'mckinsey_higher_ed'],
		intent: 'commercial',
	},
};

const exported = JSON.parse(fs.readFileSync(exportPath, 'utf8'));
const current = JSON.parse(fs.readFileSync(postsPath, 'utf8'));

const merged = current.map((post) => {
	const ex = exported[post.slug];
	const meta = META[post.slug] ?? {};
	if (!ex) {
		console.warn('Missing export for', post.slug);
		return { ...post, ...meta };
	}
	return {
		slug: post.slug,
		title: ex.seoTitle || post.title,
		excerpt: ex.excerpt || post.excerpt,
		focusKeyword: ex.focusKeyword || post.focusKeyword,
		featuredImage: meta.featuredImage || ex.featuredImage || 'student',
		outboundRefs: meta.outboundRefs || [],
		intent: meta.intent || 'informational',
		contentHtml: ex.contentHtml,
	};
});

fs.writeFileSync(postsPath, JSON.stringify(merged, null, 2) + '\n');
console.log(`Updated ${postsPath} (${merged.length} posts)`);
for (const p of merged) {
	const words = (p.contentHtml || '')
		.replace(/<[^>]+>/g, ' ')
		.replace(/\s+/g, ' ')
		.trim()
		.split(/\s+/)
		.filter(Boolean).length;
	console.log(`  ${String(words).padStart(4)}  ${p.slug}`);
}
