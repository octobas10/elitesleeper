# Higher Learning Marketers — Astro site

Static marketing site migrated from WordPress. No PHP, no MySQL on the public server.

## Quick start

```bash
cd astro
cp .env.example .env
npm install
npm run dev
```

Open http://localhost:4321

## Build & preview

```bash
npm run build
npm run preview
```

## Deploy with Docker (recommended for your server)

```bash
cd astro
cp .env.example .env    # edit with your API keys
bash docker-up.sh       # build + start on port 4321
```

Or manually:

```bash
docker compose build
docker compose up -d
docker compose logs -f hlm-astro
```

Site runs at **http://localhost:4321** (or map port 80 in `docker-compose.yml`).

### Production on Rackspace / VPS

1. Copy the `astro/` folder to your server
2. Create `.env` with production secrets
3. Run `docker compose up -d --build`
4. Point Nginx/Caddy reverse proxy to `localhost:4321`
5. Point DNS to the new server — retire WordPress

Lead submissions persist in Docker volume `hlm_leads` as SQLite (`leads.db`) plus JSON backups.

---

## Deploy to Cloudflare Pages (alternative)

See [DEPLOY.md](./DEPLOY.md) for Cloudflare setup (requires switching adapter back to `@astrojs/cloudflare`).

## Pages (WordPress parity)

| Path | Page |
|------|------|
| `/` | Home + 3-step student / 2-step university forms |
| `/about-us/` | About + FAQs |
| `/services/` | Services hub |
| `/services/lead-generation/` | Service detail (×6 services) |
| `/affiliations/` | Affiliations + FAQs |
| `/contact-us/` | Contact + forms |
| `/blog/` | Blog index (16 articles) |
| `/blog/{slug}/` | Individual posts |
| `/privacy-policy/` | Full 10-section privacy policy |

**SEO:** per-page titles/descriptions, Open Graph, Twitter cards, Organization + FAQ JSON-LD, `sitemap-index.xml`, `robots.txt`.

## Lead forms

- **Student:** 3-step wizard with institution → campus → program cascading selects (Elite catalog)
- **University:** 2-step partnership wizard
- TCPA consent, honeypot, rate limiting, server validation mirroring WordPress
- Client-side field validation with inline error messages on Continue / submit
- `POST /api/submit` — SQLite DB (`data/leads/leads.db`) + JSON backup, optional Elite API (`ELITE_PROMO_CODE`) + webhook/email notification
- **Admin panel:** `/admin/` — password-protected leads UI (`ADMIN_PASSWORD`)
- **Security:** see [SECURITY.md](./SECURITY.md) — Cloudflare (whole-site DDoS/WAF), Turnstile on forms + admin login, IP allowlist, rate limits, security headers

## Styles

Copied from `site/wp-content/themes/hlm-theme-kadence/assets/hlm/` — same design tokens and BEM classes.

## WordPress folder

The `site/` WordPress tree remains for reference. Production should use this Astro app instead.
