// @ts-check
import { defineConfig } from 'astro/config';
import node from '@astrojs/node';
import sitemap from '@astrojs/sitemap';

// Node adapter — used for Docker / VPS deployment.
// For Cloudflare Pages, switch to @astrojs/cloudflare (see DEPLOY.md).
export default defineConfig({
	output: 'server',
	adapter: node({ mode: 'standalone' }),
	site: 'https://higherlearningmarketers.com',
	trailingSlash: 'always',
	integrations: [sitemap()],
});
