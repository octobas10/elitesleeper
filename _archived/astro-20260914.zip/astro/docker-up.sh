#!/usr/bin/env bash
# Build and run the Astro site in Docker (from astro/ directory).
set -euo pipefail

cd "$(dirname "$0")"

if [ ! -f .env ]; then
  echo "Creating .env from .env.example — edit it with your API keys."
  cp .env.example .env
fi

docker compose build
docker compose up -d

echo ""
echo "HLM Astro is running at http://localhost:${ASTRO_PORT:-4321}"
echo "Logs: docker compose logs -f hlm-astro"
echo "Stop: docker compose down"
