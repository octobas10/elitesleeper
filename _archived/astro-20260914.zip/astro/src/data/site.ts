export const site = {
	name: 'Higher Learning Marketers',
	tagline: 'Education Lead Generation',
	url: 'https://higherlearningmarketers.com',
	description:
		'U.S.-focused education lead generation connecting universities with motivated students.',
	logo: '/favicon.svg',
	logoPng: '/favicon/site-icon-512.png',
} as const;

export const contact = {
	email: 'support@higherlearningmarketers.com',
	phoneDisplay: '+1 (718) 655-2573',
	phoneHref: 'tel:+17186552573',
	addressLine1: '138-07 82nd Drive',
	addressLine2: 'Briarwood, NY 11435',
	addressDisplay: '138-07 82nd Drive, Briarwood, NY 11435',
	addressHref:
		'https://maps.google.com/?q=138-07+82nd+Drive,+Briarwood,+NY+11435',
	mapEmbedUrl:
		'https://maps.google.com/maps?q=138-07+82nd+Drive,+Briarwood,+NY+11435&z=15&output=embed',
	hours: 'Monday – Friday, 9:00 AM – 6:00 PM ET',
} as const;

export const nav = [
	{ label: 'About Us', href: '/about-us/' },
	{ label: 'Services', href: '/services/' },
	{ label: 'Affiliations', href: '/affiliations/' },
	{ label: 'Blog', href: '/blog/' },
	{ label: 'Contact Us', href: '/contact-us/' },
] as const;

export const media = {
	hero_home_poster:
		'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=1920&h=1080&fit=crop',
	page_about:
		'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1920&h=800&fit=crop',
	page_services:
		'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1920&h=800&fit=crop',
	page_affiliations:
		'https://images.unsplash.com/photo-1523050854058-8df87810e8fa?w=1920&h=800&fit=crop',
	page_contact:
		'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1920&h=800&fit=crop',
	partner_story:
		'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800&h=600&fit=crop',
	partner_ygo:
		'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800&h=600&fit=crop',
	team_victor:
		'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=600&h=400&fit=crop&crop=face',
	team_robert:
		'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=600&h=400&fit=crop&crop=face',
} as const;
