import { defineMiddleware } from 'astro:middleware';
import { isAdminConfigured, isValidAdminSession } from './lib/admin-auth';
import { adminIpBlockedResponse, isAdminIpAllowed } from './lib/admin-allowlist';
import { getClientIp } from './lib/client-ip';
import { isRateLimited } from './lib/rate-limit';

function isAdminPath(pathname: string): boolean {
	return pathname === '/admin' || pathname.startsWith('/admin/') || pathname.startsWith('/api/admin/');
}

function isPublicAdminPath(pathname: string): boolean {
	return (
		pathname === '/admin/login' ||
		pathname === '/admin/login/' ||
		pathname === '/api/admin/login' ||
		pathname === '/api/admin/login/'
	);
}

function withSecurityHeaders(response: Response): Response {
	const headers = new Headers(response.headers);
	headers.set('X-Content-Type-Options', 'nosniff');
	headers.set('X-Frame-Options', 'DENY');
	headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
	headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
	headers.set('Cross-Origin-Opener-Policy', 'same-origin');
	headers.set('X-DNS-Prefetch-Control', 'off');
	if (!headers.has('Cache-Control') && response.status === 200) {
		// don't override intentional cache headers; leave alone
	}
	return new Response(response.body, {
		status: response.status,
		statusText: response.statusText,
		headers,
	});
}

export const onRequest = defineMiddleware(async (context, next) => {
	const { pathname } = context.url;

	// Light burst shield for all API routes (app-level; Cloudflare still needed for real DDoS)
	if (pathname.startsWith('/api/')) {
		const ip = getClientIp(context.request);
		if (isRateLimited('api-burst', ip, 120, 60_000)) {
			return withSecurityHeaders(
				new Response(JSON.stringify({ error: 'Too many requests' }), {
					status: 429,
					headers: { 'Content-Type': 'application/json' },
				}),
			);
		}
	}

	if (isAdminPath(pathname)) {
		const ip = getClientIp(context.request);
		if (!isAdminIpAllowed(ip)) {
			return withSecurityHeaders(adminIpBlockedResponse(pathname.startsWith('/api/admin/')));
		}

		if (!isPublicAdminPath(pathname)) {
			if (!isAdminConfigured()) {
				if (pathname.startsWith('/api/admin/')) {
					return withSecurityHeaders(
						new Response(JSON.stringify({ error: 'Admin password is not configured' }), {
							status: 503,
							headers: { 'Content-Type': 'application/json' },
						}),
					);
				}
				return context.redirect('/admin/login/?error=not_configured');
			}

			const ok = await isValidAdminSession(context.request.headers.get('cookie'));
			if (!ok) {
				if (pathname.startsWith('/api/admin/')) {
					return withSecurityHeaders(
						new Response(JSON.stringify({ error: 'Unauthorized' }), {
							status: 401,
							headers: { 'Content-Type': 'application/json' },
						}),
					);
				}
				const nextPath = `${pathname}${context.url.search}`;
				return context.redirect(`/admin/login/?next=${encodeURIComponent(nextPath)}`);
			}
		}
	}

	const response = await next();
	return withSecurityHeaders(response);
});
