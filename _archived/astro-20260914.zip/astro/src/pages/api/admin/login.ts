import type { APIRoute } from 'astro';
import {
	adminSessionCookie,
	createAdminSessionToken,
	isAdminConfigured,
	verifyAdminPassword,
} from '../../../lib/admin-auth';
import { getClientIp } from '../../../lib/client-ip';
import { isRateLimited } from '../../../lib/rate-limit';
import { getTurnstileSecretKey, verifyTurnstileToken } from '../../../lib/turnstile';

export const prerender = false;

const LOGIN_MAX = 5;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;

function json(payload: Record<string, unknown>, status = 200, headers?: HeadersInit) {
	return new Response(JSON.stringify(payload), {
		status,
		headers: { 'Content-Type': 'application/json', ...headers },
	});
}

export const POST: APIRoute = async ({ request }) => {
	if (!isAdminConfigured()) {
		return json({ error: 'Set ADMIN_PASSWORD in .env to enable the admin panel' }, 503);
	}

	const ip = getClientIp(request);
	if (isRateLimited('admin-login', ip, LOGIN_MAX, LOGIN_WINDOW_MS)) {
		return json({ error: 'Too many login attempts. Try again in 15 minutes.' }, 429);
	}

	let body: { password?: string; 'cf-turnstile-response'?: string; turnstile_token?: string };
	try {
		body = await request.json();
	} catch {
		return json({ error: 'Invalid JSON' }, 400);
	}

	if (getTurnstileSecretKey()) {
		const token = String(body['cf-turnstile-response'] || body.turnstile_token || '');
		const check = await verifyTurnstileToken(token, ip);
		if (!check.ok) {
			return json({ error: check.error }, 400);
		}
	}

	const password = body.password?.trim() || '';
	if (!(await verifyAdminPassword(password))) {
		return json({ error: 'Invalid password' }, 401);
	}

	const token = await createAdminSessionToken(password);
	return json({ ok: true }, 200, { 'Set-Cookie': adminSessionCookie(token) });
};
