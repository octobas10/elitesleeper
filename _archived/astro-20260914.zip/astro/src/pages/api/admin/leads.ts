import type { APIRoute } from 'astro';
import { getLeadCounts, listLeads } from '../../../lib/lead-storage';

export const prerender = false;

function json(payload: Record<string, unknown>, status = 200) {
	return new Response(JSON.stringify(payload), {
		status,
		headers: { 'Content-Type': 'application/json' },
	});
}

export const GET: APIRoute = async ({ url }) => {
	const page = Math.max(Number(url.searchParams.get('page') || '1'), 1);
	const limit = Math.min(Math.max(Number(url.searchParams.get('limit') || '50'), 1), 200);
	const formType = url.searchParams.get('form_type') || '';
	const q = url.searchParams.get('q') || '';
	const offset = (page - 1) * limit;

	try {
		const [result, counts] = await Promise.all([
			listLeads({ formType, q, limit, offset }),
			getLeadCounts(),
		]);

		return json({
			ok: true,
			leads: result.leads,
			total: result.total,
			page,
			limit: result.limit,
			pages: Math.max(Math.ceil(result.total / result.limit), 1),
			counts,
		});
	} catch (err) {
		console.error('[hlm-admin] list leads failed', err);
		return json({ error: 'Failed to read leads' }, 500);
	}
};
