import type { APIRoute } from 'astro';
import { validateLead, digitsOnly } from '../../lib/validate-lead';
import { storeLead } from '../../lib/lead-storage';
import { notifyLead } from '../../lib/notify-lead';
import { getClientIp } from '../../lib/client-ip';
import { isRateLimited } from '../../lib/rate-limit';
import { getTurnstileSecretKey, verifyTurnstileToken } from '../../lib/turnstile';

const WINDOW_MS = 15 * 60 * 1000;
const MAX_SUBMITS = 5;

function json(payload: Record<string, unknown>, status = 200) {
	return new Response(JSON.stringify(payload), {
		status,
		headers: { 'Content-Type': 'application/json' },
	});
}

async function postToElite(formType: string, data: Record<string, string>, ip: string): Promise<void> {
	const promo = process.env.ELITE_PROMO_CODE || import.meta.env.ELITE_PROMO_CODE;
	const mode = process.env.ELITE_LEAD_MODE || import.meta.env.ELITE_LEAD_MODE || 'test';
	if (!promo) return;

	const tcpaText =
		data.tcpa_text ||
		'I agree to be contacted by phone, email, and text message regarding educational opportunities.';

	const body = new URLSearchParams({
		lead_mode: mode,
		promo_code: promo,
		sub_id: `hlm-astro-${formType}`,
		datetime_stamp: new Date().toISOString().slice(0, 19).replace('T', ' '),
		first_name: data.first_name,
		last_name: data.last_name,
		email: data.email,
		phone: digitsOnly(data.phone),
		mobile: digitsOnly(data.phone),
		address: data.address,
		city: data.city,
		state: data.state.toUpperCase().slice(0, 2),
		zip: data.zip,
		education_level: data.education_level,
		desired_degree: data.desired_degree,
		program_of_interest: data.program_of_interest,
		campus: data.campus,
		grad_year: data.grad_year,
		ipaddress: ip,
		url: data.page_url || '',
		tcpa_text: tcpaText.slice(0, 200),
		trustedformcerturl: data.trustedformcerturl || '',
		universal_leadid: data.universal_leadid || '',
	});

	const res = await fetch('https://elitebizpanel.com/edu/postprocess', {
		method: 'POST',
		headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
		body,
	});
	if (!res.ok) {
		throw new Error(`Elite HTTP ${res.status}`);
	}
}

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
	const ip = getClientIp(request);
	if (isRateLimited('lead-submit', ip, MAX_SUBMITS, WINDOW_MS)) {
		return json({ error: 'Too many submissions. Try again later.' }, 429);
	}

	let body: Record<string, unknown>;
	try {
		body = await request.json();
	} catch {
		return json({ error: 'Invalid JSON.' }, 400);
	}

	if (body.hlm_hp_url) {
		return json({ ok: true });
	}

	if (getTurnstileSecretKey()) {
		const token = String(body['cf-turnstile-response'] || body.turnstile_token || '');
		const check = await verifyTurnstileToken(token, ip);
		if (!check.ok) {
			return json({ error: check.error }, 400);
		}
	}

	const skipKeys = new Set(['form_type', 'hlm_hp_url', 'cf-turnstile-response', 'turnstile_token']);
	const formType = String(body.form_type || '');
	const data = Object.fromEntries(
		Object.entries(body)
			.filter(([k]) => !skipKeys.has(k))
			.map(([k, v]) => [k, String(v ?? '')]),
	) as Record<string, string>;

	const result = validateLead(formType, data);
	if (!result.ok) {
		return json({ error: result.error, fields: result.fields }, 400);
	}

	const runtimeEnv = (locals as { runtime?: { env?: Record<string, unknown> } }).runtime?.env;

	let leadId: string | undefined;
	try {
		leadId = await storeLead(formType, { ...data, ip }, runtimeEnv as Parameters<typeof storeLead>[2]);
	} catch (err) {
		console.error('[hlm-lead] storage failed', err);
		return json({ error: 'Could not save your submission. Please try again.' }, 500);
	}

	if (formType === 'student') {
		try {
			await postToElite(formType, data, ip);
		} catch (err) {
			console.error('[hlm-lead] elite failed', err);
		}
	}

	try {
		await notifyLead(formType, data);
	} catch (err) {
		console.error('[hlm-lead] notify failed', err);
	}

	return json({ ok: true, message: 'Lead submitted successfully.', lead_id: leadId });
};
