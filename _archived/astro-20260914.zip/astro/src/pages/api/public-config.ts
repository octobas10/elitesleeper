import type { APIRoute } from 'astro';
import { getTurnstileSiteKey } from '../../lib/turnstile';

export const prerender = false;

export const GET: APIRoute = async () => {
	return new Response(
		JSON.stringify({
			turnstileSiteKey: getTurnstileSiteKey() || null,
		}),
		{
			status: 200,
			headers: {
				'Content-Type': 'application/json',
				'Cache-Control': 'no-store',
			},
		},
	);
};
