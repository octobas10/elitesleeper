import institutionData from '../data/institution-data.json';

type InstitutionData = {
	campus: Record<string, Record<string, string>>;
	programs: Record<string, Record<string, Record<string, string>>>;
};

const catalog = institutionData as InstitutionData;
const campusData = catalog.campus;
const programData = catalog.programs;

function digitsOnly(value: string) {
	return String(value || '').replace(/\D/g, '');
}

function formatPhoneDisplay(value: string) {
	const digits = digitsOnly(value).slice(0, 10);
	if (digits.length <= 3) return digits;
	if (digits.length <= 6) return `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
	return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
}

function isValidZip(zip: string) {
	const z = String(zip || '').trim();
	return /^\d{5}(-\d{4})?$/.test(z) || /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/.test(z);
}

function isValidName(name: string) {
	return /^[A-Za-z\u00C0-\u024F\s'.-]{2,}$/.test(String(name || '').trim());
}

function setFieldInvalid(field: HTMLElement, isInvalid: boolean) {
	const group = field.closest('.hlm-form-group') || field.closest('.hlm-combobox');
	group?.classList.toggle('hlm-form-group--invalid', isInvalid);
}

function ensureFieldErrorEl(field: HTMLElement) {
	const group = field.closest('.hlm-form-group') || field.closest('.hlm-combobox');
	if (!group) return null;

	let el = group.querySelector<HTMLElement>('.hlm-field-error');
	if (!el) {
		el = document.createElement('p');
		el.className = 'hlm-field-error';
		el.setAttribute('role', 'alert');
		el.hidden = true;
		el.id = `hlm-err-${Math.random().toString(36).slice(2, 9)}`;

		let anchor: Element = field;
		if ((field as HTMLInputElement).type === 'hidden') {
			const comboboxInput = group.querySelector('.hlm-combobox-input');
			if (comboboxInput) anchor = comboboxInput;
		}

		if (anchor.parentNode) {
			anchor.insertAdjacentElement('afterend', el);
		} else {
			group.appendChild(el);
		}
	}
	return el;
}

function setFieldError(field: HTMLElement, message: string) {
	const group = field.closest('.hlm-form-group') || field.closest('.hlm-combobox');
	const errorEl = ensureFieldErrorEl(field);

	if (message) {
		setFieldInvalid(field, true);
		field.setAttribute('aria-invalid', 'true');
		if (errorEl) {
			errorEl.textContent = message;
			errorEl.hidden = false;
			const hint = group?.querySelector('.hlm-field-hint');
			const describedBy: string[] = [];
			if (hint?.id) describedBy.push(hint.id);
			describedBy.push(errorEl.id);
			field.setAttribute('aria-describedby', describedBy.join(' '));
		}
		return;
	}

	setFieldInvalid(field, false);
	field.removeAttribute('aria-invalid');
	if (errorEl) {
		errorEl.hidden = true;
		errorEl.textContent = '';
	}
}

function getFieldLabel(field: HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement) {
	const group = field.closest('.hlm-form-group') || field.closest('.hlm-combobox');
	const label = group?.querySelector('label');
	if (label) return (label.textContent || '').replace(/\*/g, '').replace(/optional/gi, '').trim();
	return field.name || 'This field';
}

function validateField(field: HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement): string {
	if (field.classList.contains('hlm-hp') || field.closest('.hlm-hp-field')) return '';
	if (field.disabled) return '';
	if (field.type === 'hidden' && field.name !== 'program_of_interest') return '';

	const value = field.type === 'checkbox' ? (field as HTMLInputElement).checked : String(field.value || '').trim();
	const label = getFieldLabel(field);

	if (field.name === 'program_of_interest' && field.required && !value) {
		return 'Please select a program from the list.';
	}

	if (field.required && !value) {
		if (field.type === 'checkbox') return 'Please check the box to continue.';
		if (field.tagName === 'SELECT') return `Please select ${label}.`;
		return `Please enter ${label}.`;
	}

	if (!value && !field.required) return '';

	if (field.type === 'email' || field.name === 'email') {
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))) {
			return 'Please enter a valid email address.';
		}
	}

	if (field.type === 'tel' || field.name === 'phone') {
		if (digitsOnly(String(value)).length !== 10) {
			return 'Please enter a 10-digit phone number.';
		}
	}

	if (field.name === 'zip' && !isValidZip(String(value))) {
		return 'Enter a valid ZIP (12345) or postal code (A1A 1A1).';
	}

	if (
		(field.name === 'first_name' || field.name === 'last_name' || field.name === 'institution_name') &&
		!isValidName(String(value))
	) {
		return 'Please enter at least 2 characters.';
	}

	if ((field.type === 'url' || field.name === 'website') && value) {
		if (!/^https?:\/\/.+\..+/i.test(String(value))) {
			return 'Please enter a full website URL starting with https://';
		}
	}

	return '';
}

function validateFields(fields: NodeListOf<Element> | Element[]) {
	let firstInvalid: HTMLElement | null = null;
	let firstMessage = '';

	fields.forEach((raw) => {
		const field = raw as HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;
		const msg = validateField(field);
		setFieldError(field, msg);
		if (msg && !firstInvalid) {
			firstInvalid = field;
			firstMessage = msg;
		}
	});

	return { valid: !firstInvalid, field: firstInvalid, message: firstMessage };
}

function focusField(field: HTMLElement | null) {
	if (!field) return;
	if ((field as HTMLInputElement).type === 'hidden') {
		const input = field.closest('.hlm-combobox')?.querySelector<HTMLInputElement>('.hlm-combobox-input');
		input?.focus();
		return;
	}
	field.focus();
}

function initFieldValidation(root: ParentNode) {
	root.querySelectorAll<HTMLFormElement>('.hlm-lead-form').forEach((form) => {
		form.querySelectorAll<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>(
			'input, select, textarea',
		).forEach((field) => {
			if (field.type === 'tel' || field.name === 'phone') {
				field.addEventListener('input', () => {
					const formatted = formatPhoneDisplay(field.value);
					if (field.value !== formatted) field.value = formatted;
					if (!validateField(field)) setFieldError(field, '');
				});
			}

			field.addEventListener('blur', () => {
				if (field.type === 'hidden' || field.classList.contains('hlm-hp')) return;
				setFieldError(field, validateField(field));
			});

			field.addEventListener('input', () => {
				if (field.type === 'tel' || field.name === 'phone') return;
				if (!validateField(field)) setFieldError(field, '');
			});

			field.addEventListener('change', () => {
				if (!validateField(field)) setFieldError(field, '');
			});
		});
	});
}

function populateSelect(select: HTMLSelectElement, options: Record<string, string>, placeholder: string) {
	select.innerHTML = '';
	const empty = document.createElement('option');
	empty.value = '';
	empty.textContent = placeholder;
	select.appendChild(empty);
	for (const [value, label] of Object.entries(options)) {
		const opt = document.createElement('option');
		opt.value = value;
		opt.textContent = label;
		select.appendChild(opt);
	}
}

function initWizard(form: HTMLFormElement) {
	const steps = Array.from(form.querySelectorAll<HTMLElement>('.hlm-form-step'));
	const progressFill = form.querySelector<HTMLElement>('.hlm-form-progress-fill');
	const stepCurrent = form.querySelector<HTMLElement>('.hlm-step-current');
	const total = steps.length;
	let current = 1;

	function validateStep(stepEl: HTMLElement) {
		const result = validateFields(stepEl.querySelectorAll('input, select, textarea'));
		if (!result.valid) {
			stepEl.classList.add('hlm-form-step--validated');
			focusField(result.field);
			return false;
		}
		return true;
	}

	function goToStep(stepNum: number) {
		current = Math.max(1, Math.min(total, stepNum));
		steps.forEach((step) => {
			const isActive = parseInt(step.dataset.step || '0', 10) === current;
			step.classList.toggle('active', isActive);
			step.hidden = !isActive;
		});
		if (progressFill) progressFill.style.width = `${(current / total) * 100}%`;
		if (stepCurrent) stepCurrent.textContent = String(current);
		if (current === total) {
			form.dispatchEvent(new CustomEvent('hlm:step-final'));
		}
	}

	form.querySelectorAll('.hlm-form-next').forEach((button) => {
		button.addEventListener('click', () => {
			const stepEl = button.closest('.hlm-form-step') as HTMLElement | null;
			if (!stepEl || !validateStep(stepEl)) return;
			goToStep(current + 1);
		});
	});

	form.querySelectorAll('.hlm-form-back').forEach((button) => {
		button.addEventListener('click', () => goToStep(current - 1));
	});

	form.addEventListener('hlm:reset-steps', () => goToStep(1));
	form.addEventListener('hlm:goto-step', ((event: CustomEvent<{ step?: number }>) => {
		if (event.detail?.step) goToStep(event.detail.step);
	}) as EventListener);
	goToStep(1);
}

function initProgramCombobox(combobox: HTMLElement) {
	const hidden = combobox.querySelector<HTMLInputElement>('input[type="hidden"][name="program_of_interest"]');
	const input = combobox.querySelector<HTMLInputElement>('.hlm-combobox-input');
	const list = combobox.querySelector<HTMLUListElement>('.hlm-combobox-list');
	const countEl = combobox.querySelector<HTMLElement>('.hlm-combobox-count');
	const form = combobox.closest('form');
	if (!hidden || !input || !list) return;

	let options: { code: string; label: string }[] = [];
	let filtered: typeof options = [];
	let activeIndex = -1;

	function setOptions(programMap: Record<string, string>) {
		options = Object.entries(programMap || {})
			.map(([code, label]) => ({ code, label }))
			.sort((a, b) => a.label.localeCompare(b.label));
		filtered = options.slice();
		renderList();
		updateCount();
	}

	function clearSelection() {
		hidden.value = '';
		input.value = '';
		input.disabled = true;
		input.placeholder = 'Select campus first, then search programs...';
		closeList();
		options = [];
		filtered = [];
		renderList();
		updateCount();
		setFieldError(hidden, '');
	}

	function updateCount() {
		if (!countEl) return;
		if (!options.length) {
			countEl.hidden = true;
			return;
		}
		countEl.hidden = false;
		countEl.textContent = `${options.length} programs available`;
	}

	function closeList() {
		list.hidden = true;
		input.setAttribute('aria-expanded', 'false');
		activeIndex = -1;
	}

	function openList() {
		if (!filtered.length || input.disabled) return;
		list.hidden = false;
		input.setAttribute('aria-expanded', 'true');
	}

	function renderList() {
		list.innerHTML = '';
		filtered.forEach((item, index) => {
			const li = document.createElement('li');
			li.className = 'hlm-combobox-option';
			li.setAttribute('role', 'option');
			li.dataset.code = item.code;
			li.textContent = item.label;
			if (index === activeIndex) {
				li.classList.add('is-active');
				li.setAttribute('aria-selected', 'true');
			}
			li.addEventListener('mousedown', (e) => {
				e.preventDefault();
				hidden.value = item.code;
				input.value = item.label;
				setFieldError(hidden, '');
				closeList();
			});
			list.appendChild(li);
		});
	}

	function filterOptions(query: string) {
		const q = query.trim().toLowerCase();
		filtered = !q
			? options.slice()
			: options.filter(
					(item) =>
						item.label.toLowerCase().includes(q) || item.code.toLowerCase().includes(q),
				);
		activeIndex = filtered.length ? 0 : -1;
		renderList();
		openList();
	}

	input.addEventListener('focus', () => {
		if (!input.disabled) filterOptions(input.value);
	});
	input.addEventListener('input', () => {
		hidden.value = '';
		filterOptions(input.value);
	});
	input.addEventListener('keydown', (event) => {
		if (input.disabled) return;
		if (event.key === 'ArrowDown') {
			event.preventDefault();
			if (list.hidden) openList();
			else activeIndex = Math.min(activeIndex + 1, filtered.length - 1);
			renderList();
		} else if (event.key === 'ArrowUp') {
			event.preventDefault();
			activeIndex = Math.max(activeIndex - 1, 0);
			renderList();
		} else if (event.key === 'Enter' && activeIndex >= 0 && filtered[activeIndex]) {
			event.preventDefault();
			hidden.value = filtered[activeIndex].code;
			input.value = filtered[activeIndex].label;
			setFieldError(hidden, '');
			closeList();
		} else if (event.key === 'Escape') {
			closeList();
		}
	});

	document.addEventListener('click', (event) => {
		if (!combobox.contains(event.target as Node)) closeList();
	});

	if (form) {
		form.addEventListener('hlm:programs-updated', (event: Event) => {
			const detail = (event as CustomEvent).detail;
			if (detail?.combobox === combobox) {
				setOptions(detail.programs || {});
				input.disabled = false;
				input.placeholder = 'Search or select a program...';
			}
		});
		form.addEventListener('hlm:programs-cleared', () => clearSelection());
	}

	(combobox as HTMLElement & { hlmClearPrograms?: () => void }).hlmClearPrograms = clearSelection;
}

function dispatchPrograms(form: HTMLFormElement, combobox: HTMLElement, programs: Record<string, string>) {
	form.dispatchEvent(
		new CustomEvent('hlm:programs-updated', { detail: { combobox, programs } }),
	);
}

function initStudentCascades(root: ParentNode) {
	const form = root.querySelector<HTMLFormElement>('[data-type="student"]');
	if (!form) return;

	const category = form.querySelector<HTMLSelectElement>('.hlm-student-category');
	const campus = form.querySelector<HTMLSelectElement>('.hlm-student-campus');
	const combobox = form.querySelector<HTMLElement>('.hlm-program-combobox');
	if (!category || !campus || !combobox) return;

	category.addEventListener('change', () => {
		form.dispatchEvent(new CustomEvent('hlm:programs-cleared'));
		const cat = category.value;
		if (cat && campusData[cat]) {
			populateSelect(campus, campusData[cat], 'Select campus');
			campus.disabled = false;
			campus.value = '';
		} else {
			populateSelect(campus, {}, 'Select campus');
			campus.disabled = true;
			campus.value = '';
		}
	});

	campus.addEventListener('change', () => {
		const cat = category.value;
		const camp = campus.value;
		if (cat && camp && programData[cat]?.[camp]) {
			dispatchPrograms(form, combobox, programData[cat][camp]);
		} else {
			form.dispatchEvent(new CustomEvent('hlm:programs-cleared'));
		}
	});

	form.addEventListener('hlm:step-final', () => {
		const cat = category.value;
		const camp = campus.value;
		if (cat && camp && programData[cat]?.[camp]) {
			dispatchPrograms(form, combobox, programData[cat][camp]);
		}
	});
}

function mergeCompliance(root: ParentNode, payload: Record<string, unknown>) {
	for (const name of ['trustedformcerturl', 'universal_leadid', 'page_url']) {
		const field = root.querySelector<HTMLInputElement>(`[name="${name}"]`);
		if (field?.value) payload[name] = field.value;
	}
	if (!payload.page_url) payload.page_url = window.location.href;
}

type TurnstileApi = {
	render: (el: HTMLElement, opts: { sitekey: string; theme?: string; size?: string }) => string;
	reset: (widgetId?: string | HTMLElement) => void;
};

function getTurnstileApi(): TurnstileApi | undefined {
	return (window as Window & { turnstile?: TurnstileApi }).turnstile;
}

function loadTurnstileScript(): Promise<void> {
	if (getTurnstileApi()) return Promise.resolve();
	const existing = document.querySelector('script[src*="challenges.cloudflare.com/turnstile"]');
	if (existing) {
		return new Promise((resolve) => {
			existing.addEventListener('load', () => resolve(), { once: true });
			// Already loaded
			if (getTurnstileApi()) resolve();
		});
	}
	return new Promise((resolve, reject) => {
		const script = document.createElement('script');
		script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
		script.async = true;
		script.onload = () => resolve();
		script.onerror = () => reject(new Error('Failed to load security check'));
		document.head.appendChild(script);
	});
}

async function ensureTurnstileWidgets(root: ParentNode) {
	try {
		const res = await fetch('/api/public-config/');
		const data = (await res.json().catch(() => ({}))) as { turnstileSiteKey?: string | null };
		const siteKey = data.turnstileSiteKey?.trim();
		if (!siteKey) return;

		await loadTurnstileScript();
		const api = getTurnstileApi();
		if (!api) return;

		root.querySelectorAll<HTMLFormElement>('.hlm-lead-form').forEach((form) => {
			if (form.querySelector('.cf-turnstile, .hlm-turnstile-wrap')) return;
			const actions = form.querySelector('.hlm-form-step:last-of-type .hlm-form-step-actions');
			if (!actions) return;
			const wrap = document.createElement('div');
			wrap.className = 'hlm-turnstile-wrap';
			const widget = document.createElement('div');
			widget.className = 'cf-turnstile';
			wrap.appendChild(widget);
			actions.parentElement?.insertBefore(wrap, actions);
			api.render(widget, { sitekey: siteKey, theme: 'light', size: 'flexible' });
		});
	} catch (err) {
		console.warn('[hlm-turnstile] bootstrap failed', err);
	}
}

function applyServerFieldErrors(form: HTMLFormElement, fields: unknown) {
	if (!Array.isArray(fields)) return;
	for (const name of fields) {
		if (typeof name !== 'string') continue;
		const field = form.querySelector<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>(
			`[name="${CSS.escape(name)}"]`,
		);
		if (!field) continue;
		const stepEl = field.closest('.hlm-form-step') as HTMLElement | null;
		stepEl?.classList.add('hlm-form-step--validated');
		setFieldError(field, validateField(field) || 'Please complete this field.');
	}
}

const captureRoot = document.querySelector('[data-hlm-lead-capture]');
if (captureRoot) {
	void ensureTurnstileWidgets(captureRoot);

	const tabButtons = captureRoot.querySelectorAll<HTMLButtonElement>('[data-tab]');
	const forms = captureRoot.querySelectorAll<HTMLFormElement>('.hlm-lead-form');
	const typeSelect = captureRoot.querySelector<HTMLSelectElement>('[data-hlm-form-tabs-select]');

	function activateType(type: string | undefined) {
		if (!type) return;
		tabButtons.forEach((b) => {
			const active = b.dataset.tab === type;
			b.classList.toggle('active', active);
			b.setAttribute('aria-selected', active ? 'true' : 'false');
		});
		forms.forEach((form) => {
			const show = form.dataset.type === type;
			form.hidden = !show;
			form.classList.toggle('active', show);
		});
		if (typeSelect && typeSelect.value !== type) typeSelect.value = type;
	}

	tabButtons.forEach((btn) => {
		btn.addEventListener('click', () => activateType(btn.dataset.tab));
	});

	typeSelect?.addEventListener('change', () => activateType(typeSelect.value));

	captureRoot.querySelectorAll('.hlm-program-combobox').forEach((box) => initProgramCombobox(box));
	initStudentCascades(captureRoot);
	initFieldValidation(captureRoot);

	forms.forEach((form) => {
		if (form.classList.contains('hlm-form-wizard')) initWizard(form);

		form.addEventListener('submit', async (event) => {
			event.preventDefault();
			const status = form.querySelector<HTMLElement>('[data-form-status]');
			const submitBtn = form.querySelector<HTMLButtonElement>('.hlm-form-submit, button[type="submit"]');
			if (!status || !submitBtn) return;

			const hp = form.querySelector<HTMLInputElement>('input[name="hlm_hp_url"]');
			if (hp?.value) return;

			const wizardSteps = form.querySelectorAll<HTMLElement>('.hlm-form-step');
			if (wizardSteps.length) {
				for (const step of wizardSteps) {
					const result = validateFields(step.querySelectorAll('input, select, textarea'));
					if (!result.valid) {
						const stepNum = parseInt(step.dataset.step || '1', 10);
						step.classList.add('hlm-form-step--validated');
						form.dispatchEvent(new CustomEvent('hlm:goto-step', { detail: { step: stepNum } }));
						focusField(result.field);
						status.hidden = true;
						return;
					}
				}
			} else {
				const result = validateFields(form.querySelectorAll('input, select, textarea'));
				if (!result.valid) {
					result.field?.closest('.hlm-form-step')?.classList.add('hlm-form-step--validated');
					focusField(result.field);
					status.hidden = true;
					return;
				}
			}

			const formData = new FormData(form);
			const payload: Record<string, unknown> = { form_type: form.dataset.type };
			formData.forEach((value, key) => {
				if (key !== 'hlm_hp_url') payload[key] = value;
			});
			mergeCompliance(captureRoot, payload);

			const turnstileInput = form.querySelector<HTMLInputElement>(
				'textarea[name="cf-turnstile-response"], input[name="cf-turnstile-response"]',
			);
			if (form.querySelector('.cf-turnstile') && !turnstileInput?.value) {
				status.hidden = false;
				status.textContent = 'Please complete the security check.';
				status.className = 'hlm-form-status is-error';
				return;
			}
			if (turnstileInput?.value) {
				payload['cf-turnstile-response'] = turnstileInput.value;
			}

			submitBtn.disabled = true;
			status.hidden = false;
			status.textContent = 'Submitting…';
			status.className = 'hlm-form-status';

			try {
				const res = await fetch('/api/submit/', {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(payload),
				});
				const data = await res.json().catch(() => ({}));
				if (!res.ok) {
					applyServerFieldErrors(form, data.fields);
					const widget = form.querySelector('.cf-turnstile');
					const api = getTurnstileApi();
					if (widget && api?.reset) {
						api.reset(widget as HTMLElement);
					}
					throw new Error(
						typeof data.error === 'string' ? data.error : 'Submission failed. Please try again.',
					);
				}
				const formType = form.dataset.type || 'student';
				const thankYou = new URL('/thank-you/', window.location.origin);
				thankYou.searchParams.set('type', formType);
				if (typeof data.lead_id === 'string' && data.lead_id) {
					thankYou.searchParams.set('ref', data.lead_id);
				}
				window.location.assign(thankYou.toString());
				return;
			} catch (err) {
				status.textContent =
					err instanceof Error ? err.message : 'Submission failed. Please try again.';
				status.className = 'hlm-form-status is-error';
			} finally {
				submitBtn.disabled = false;
			}
		});
	});
}
