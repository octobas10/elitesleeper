function reveal(el: Element) {
	el.classList.add('is-visible', 'visible');
}

function alreadySeen(el: Element) {
	const rect = el.getBoundingClientRect();
	return rect.top < window.innerHeight * 0.92;
}

function initReveal() {
	const targets = document.querySelectorAll('.hlm-animate, .hlm-section-reveal, .hlm-stagger-grid');
	if (!targets.length) return;

	if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
		targets.forEach(reveal);
		return;
	}

	if (!('IntersectionObserver' in window)) {
		targets.forEach(reveal);
		return;
	}

	const observer = new IntersectionObserver(
		(entries) => {
			for (const entry of entries) {
				if (!entry.isIntersecting) continue;
				reveal(entry.target);
				observer.unobserve(entry.target);
			}
		},
		{ rootMargin: '0px 0px -8% 0px', threshold: 0.12 },
	);

	targets.forEach((el) => {
		if (alreadySeen(el)) {
			reveal(el);
			return;
		}
		observer.observe(el);
	});

	document.querySelectorAll('.hlm-hero .hlm-animate').forEach(reveal);
}

if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', initReveal);
} else {
	initReveal();
}
