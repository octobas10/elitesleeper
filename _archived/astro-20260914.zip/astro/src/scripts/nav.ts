function openDrawer(toggle: HTMLButtonElement, drawer: HTMLElement) {
	drawer.hidden = false;
	toggle.setAttribute('aria-expanded', 'true');
	toggle.setAttribute('aria-label', 'Close menu');
	document.body.classList.add('hlm-nav-open');
	document.body.style.overflow = 'hidden';
}

function closeDrawer(toggle: HTMLButtonElement, drawer: HTMLElement) {
	drawer.hidden = true;
	toggle.setAttribute('aria-expanded', 'false');
	toggle.setAttribute('aria-label', 'Open menu');
	document.body.classList.remove('hlm-nav-open');
	document.body.style.overflow = '';
}

const header = document.getElementById('masthead');
if (header) {
	const onScroll = () => {
		const scrolled = window.scrollY > 8;
		header.classList.toggle('hlm-header-scrolled', scrolled);
		if (header.classList.contains('hlm-site-header--transparent')) {
			header.style.position = scrolled ? 'sticky' : 'absolute';
		}
	};
	onScroll();
	window.addEventListener('scroll', onScroll, { passive: true });
}

const toggle = document.querySelector<HTMLButtonElement>('[data-hlm-nav-toggle]');
const drawer = document.querySelector<HTMLElement>('[data-hlm-nav-drawer]');

if (toggle && drawer) {
	toggle.addEventListener('click', () => {
		if (drawer.hidden) {
			openDrawer(toggle, drawer);
		} else {
			closeDrawer(toggle, drawer);
		}
	});

	document.querySelectorAll('[data-hlm-nav-close]').forEach((el) => {
		el.addEventListener('click', () => closeDrawer(toggle, drawer));
	});
}
