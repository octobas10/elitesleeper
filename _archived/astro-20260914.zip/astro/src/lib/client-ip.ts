export function getClientIp(request: Request): string {
	const forwarded = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim();
	if (forwarded) return forwarded;
	const real = request.headers.get('x-real-ip')?.trim();
	if (real) return real;
	const cf = request.headers.get('cf-connecting-ip')?.trim();
	if (cf) return cf;
	return 'unknown';
}
