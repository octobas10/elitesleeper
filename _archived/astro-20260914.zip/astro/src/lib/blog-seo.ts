import { site } from '../data/site';

export type OutboundRef = {
	url: string;
	title: string;
	rel?: string;
};

export const outboundAuthority: Record<string, OutboundRef> = {
	bls_nursing: {
		url: 'https://www.bls.gov/ooh/healthcare/registered-nurses.htm',
		title: 'U.S. Bureau of Labor Statistics - Registered Nurses',
	},
	ncsbn: {
		url: 'https://www.ncsbn.org/',
		title: 'National Council of State Boards of Nursing',
	},
	berkeley_college: {
		url: 'https://berkeleycollege.edu/',
		title: 'Berkeley College',
	},
	nces_adult: {
		url: 'https://nces.ed.gov/fastfacts/display.asp?id=89',
		title: 'NCES - Adult Learners in Higher Education',
	},
	edgov_enrollment: {
		url: 'https://www.ed.gov/news/press-releases',
		title: 'U.S. Department of Education',
	},
	mckinsey_higher_ed: {
		url: 'https://www.mckinsey.com/industries/education/our-insights',
		title: 'McKinsey - Higher Education Insights',
	},
	fcc_tcpa: {
		url: 'https://www.fcc.gov/general/telemarketing-and-robocalls',
		title: 'FCC - Telemarketing and TCPA Rules',
	},
	studentaid_fafsa: {
		url: 'https://studentaid.gov/h/apply-for-aid/fafsa',
		title: 'Federal Student Aid - FAFSA',
	},
};

export function resolveOutboundRefs(ids: string[] = []): OutboundRef[] {
	return ids.map((id) => outboundAuthority[id]).filter(Boolean);
}

export function featuredImagePath(variant = 'student'): string {
	const allowed = new Set(['student', 'university', 'hlm', 'compliance']);
	const key = allowed.has(variant) ? variant : 'student';
	return `/images/blog/featured-${key}.svg`;
}

export function featuredImageUrl(variant = 'student'): string {
	return `${site.url.replace(/\/$/, '')}${featuredImagePath(variant)}`;
}

export function keywordImageAlt(focusKeyword: string, title: string): string {
	const kw = (focusKeyword || '').trim();
	if (kw) return `${kw} - ${title}`;
	return title;
}
