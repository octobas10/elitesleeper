type LeadEnv = {
	LEADS_KV?: {
		put: (key: string, value: string) => Promise<void>;
	};
};

type LeadRecord = {
	id: string;
	form_type: string;
	submitted_at: string;
	[key: string]: string;
};

async function storeInSqlite(formType: string, record: LeadRecord, dir: string) {
	const { DatabaseSync } = await import('node:sqlite');
	const path = await import('node:path');
	const fs = await import('node:fs/promises');

	await fs.mkdir(dir, { recursive: true });
	const db = new DatabaseSync(path.join(dir, 'leads.db'));

	try {
		db.exec(`
			CREATE TABLE IF NOT EXISTS leads (
				id TEXT PRIMARY KEY,
				form_type TEXT NOT NULL,
				status TEXT NOT NULL DEFAULT 'saved',
				first_name TEXT NOT NULL DEFAULT '',
				last_name TEXT NOT NULL DEFAULT '',
				email TEXT NOT NULL DEFAULT '',
				phone TEXT NOT NULL DEFAULT '',
				city TEXT NOT NULL DEFAULT '',
				state TEXT NOT NULL DEFAULT '',
				zip TEXT NOT NULL DEFAULT '',
				category TEXT NOT NULL DEFAULT '',
				campus TEXT NOT NULL DEFAULT '',
				program_of_interest TEXT NOT NULL DEFAULT '',
				institution_name TEXT NOT NULL DEFAULT '',
				payload TEXT NOT NULL,
				created_at TEXT NOT NULL
			);
			CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(email);
			CREATE INDEX IF NOT EXISTS idx_leads_created_at ON leads(created_at);
			CREATE INDEX IF NOT EXISTS idx_leads_form_type ON leads(form_type);
		`);

		db.prepare(`
			INSERT INTO leads (
				id, form_type, status, first_name, last_name, email, phone,
				city, state, zip, category, campus, program_of_interest,
				institution_name, payload, created_at
			) VALUES (
				?, ?, 'saved', ?, ?, ?, ?,
				?, ?, ?, ?, ?, ?,
				?, ?, ?
			)
		`).run(
			record.id,
			formType,
			record.first_name || '',
			record.last_name || '',
			record.email || '',
			record.phone || '',
			record.city || '',
			record.state || '',
			record.zip || '',
			record.category || '',
			record.campus || '',
			record.program_of_interest || '',
			record.institution_name || '',
			JSON.stringify(record),
			record.submitted_at,
		);
	} finally {
		db.close();
	}
}

async function storeAsJsonFiles(record: LeadRecord, dir: string) {
	const fs = await import('node:fs/promises');
	const path = await import('node:path');
	const json = JSON.stringify(record);
	await fs.mkdir(dir, { recursive: true });
	await fs.writeFile(path.join(dir, `${record.id}.json`), json, 'utf8');
	await fs.appendFile(path.join(dir, 'leads.jsonl'), `${json}\n`, 'utf8');
}

export async function storeLead(
	formType: string,
	data: Record<string, string>,
	env?: LeadEnv,
) {
	const id = `${Date.now()}-${formType}`;
	const record: LeadRecord = {
		id,
		form_type: formType,
		submitted_at: new Date().toISOString(),
		...data,
	};
	const json = JSON.stringify(record);

	if (env?.LEADS_KV) {
		await env.LEADS_KV.put(id, json);
		return id;
	}

	const path = await import('node:path');
	const dir =
		process.env.LEAD_STORAGE_DIR ||
		import.meta.env.LEAD_STORAGE_DIR ||
		path.join(process.cwd(), 'data', 'leads');

	let saved = false;

	try {
		await storeInSqlite(formType, record, dir);
		saved = true;
	} catch (err) {
		console.error('[hlm-lead] sqlite storage failed', err);
	}

	try {
		await storeAsJsonFiles(record, dir);
		saved = true;
	} catch (err) {
		console.error('[hlm-lead] json backup failed', err);
	}

	if (!saved) {
		throw new Error('Lead storage unavailable');
	}

	return id;
}

export type LeadRow = {
	id: string;
	form_type: string;
	status: string;
	first_name: string;
	last_name: string;
	email: string;
	phone: string;
	city: string;
	state: string;
	zip: string;
	category: string;
	campus: string;
	program_of_interest: string;
	institution_name: string;
	payload: string;
	created_at: string;
};

export type ListLeadsOptions = {
	formType?: string;
	q?: string;
	limit?: number;
	offset?: number;
};

export type ListLeadsResult = {
	leads: LeadRow[];
	total: number;
	limit: number;
	offset: number;
};

async function getLeadsDir(): Promise<string> {
	const path = await import('node:path');
	return (
		process.env.LEAD_STORAGE_DIR ||
		import.meta.env.LEAD_STORAGE_DIR ||
		path.join(process.cwd(), 'data', 'leads')
	);
}

async function openLeadsDb(readonly = true) {
	const { DatabaseSync } = await import('node:sqlite');
	const path = await import('node:path');
	const fs = await import('node:fs');
	const dir = await getLeadsDir();
	const dbPath = path.join(dir, 'leads.db');

	if (!fs.existsSync(dbPath)) {
		return null;
	}

	return new DatabaseSync(dbPath, { readOnly: readonly });
}

export async function listLeads(options: ListLeadsOptions = {}): Promise<ListLeadsResult> {
	const limit = Math.min(Math.max(options.limit ?? 50, 1), 200);
	const offset = Math.max(options.offset ?? 0, 0);
	const formType = options.formType?.trim() || '';
	const q = options.q?.trim() || '';

	const empty: ListLeadsResult = { leads: [], total: 0, limit, offset };
	const db = await openLeadsDb(true);
	if (!db) return empty;

	try {
		const where: string[] = [];
		const params: (string | number)[] = [];

		if (formType === 'student' || formType === 'university') {
			where.push('form_type = ?');
			params.push(formType);
		}

		if (q) {
			const like = `%${q}%`;
			where.push(
				'(email LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR phone LIKE ? OR id LIKE ? OR institution_name LIKE ?)',
			);
			params.push(like, like, like, like, like, like);
		}

		const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

		const totalRow = db.prepare(`SELECT COUNT(*) AS count FROM leads ${whereSql}`).get(...params) as
			| { count: number }
			| undefined;
		const total = Number(totalRow?.count ?? 0);

		const leads = db
			.prepare(
				`
			SELECT
				id, form_type, status, first_name, last_name, email, phone,
				city, state, zip, category, campus, program_of_interest,
				institution_name, payload, created_at
			FROM leads
			${whereSql}
			ORDER BY created_at DESC
			LIMIT ? OFFSET ?
		`,
			)
			.all(...params, limit, offset) as LeadRow[];

		return { leads, total, limit, offset };
	} finally {
		db.close();
	}
}

export async function getLeadCounts(): Promise<{ total: number; student: number; university: number }> {
	const db = await openLeadsDb(true);
	if (!db) return { total: 0, student: 0, university: 0 };

	try {
		const rows = db
			.prepare(
				`
			SELECT form_type, COUNT(*) AS count
			FROM leads
			GROUP BY form_type
		`,
			)
			.all() as { form_type: string; count: number }[];

		const student = Number(rows.find((r) => r.form_type === 'student')?.count ?? 0);
		const university = Number(rows.find((r) => r.form_type === 'university')?.count ?? 0);
		return { total: student + university, student, university };
	} finally {
		db.close();
	}
}

export async function getLead(id: string): Promise<LeadRow | null> {
	const db = await openLeadsDb(true);
	if (!db) return null;

	try {
		const row = db
			.prepare(
				`
			SELECT
				id, form_type, status, first_name, last_name, email, phone,
				city, state, zip, category, campus, program_of_interest,
				institution_name, payload, created_at
			FROM leads
			WHERE id = ?
		`,
			)
			.get(id) as LeadRow | undefined;

		return row ?? null;
	} finally {
		db.close();
	}
}
