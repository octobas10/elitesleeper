import seoLinks from '../data/seo-links.json';
import { blogPosts } from '../data/content';

type LinkEntry = { slug: string; anchor: string; placement: string; type: string };

const titles = seoLinks.titleBySlug as Record<string, string>;

const pageTitles: Record<string, string> = {
	home: 'Home',
	'about-us': 'About Us',
	services: 'Services',
	affiliations: 'Affiliations',
	'contact-us': 'Contact Us',
	blog: 'Blog',
	'privacy-policy': 'Privacy Policy',
	'lead-generation': 'Lead Generation',
	'brand-awareness': 'Brand Awareness',
	'multi-channel-marketing': 'Multi-Channel Marketing',
	'analytics-reporting': 'Analytics & Reporting',
	'partner-network': 'Partner Network',
	'enrollment-funnel': 'Enrollment Funnel',
};

export function resolveSlugUrl(slug: string): string {
	if (slug.startsWith('services/')) return `/${slug}/`;
	if (pageTitles[slug] || ['home', 'about-us', 'services', 'affiliations', 'contact-us', 'blog', 'privacy-policy'].includes(slug)) {
		return slug === 'home' ? '/' : `/${slug}/`;
	}
	return `/blog/${slug}/`;
}

export function resolveLinkLabel(slug: string, anchor?: string): string {
	if (anchor) return anchor;
	return titles[slug] || pageTitles[slug] || slug.replace(/-/g, ' ');
}

export function getPageResourceLinks(pageSlug: string, variant: 'footer' | 'inline' = 'footer') {
	const links = (seoLinks.internal as Record<string, LinkEntry[]>)[pageSlug] ?? [];
	const cta = links.filter((l) => l.placement === 'cta' || l.placement === 'above_fold');
	const body = links.filter((l) => l.placement === 'body' || l.placement === 'intro');
	const group = variant === 'footer' ? [...cta, ...body] : body;
	return group.map((l) => ({
		href: resolveSlugUrl(l.slug),
		label: resolveLinkLabel(l.slug, l.anchor),
	}));
}

export function getBlogClusterNav(postSlug: string) {
	for (const cluster of Object.values(seoLinks.clusters)) {
		if (!cluster.posts.includes(postSlug)) continue;
		const siblings = cluster.posts.filter((s) => s !== postSlug);
		const related = (cluster.linksTo as Record<string, string[]>)[postSlug] ?? [];
		const items = [
			{ href: cluster.pillarUrl, label: cluster.label, featured: true },
			...siblings.slice(0, 4).map((s) => ({
				href: `/blog/${s}/`,
				label: titles[s] || s,
				featured: false,
			})),
			...related.slice(0, 3).map((s) => ({
				href: resolveSlugUrl(s),
				label: resolveLinkLabel(s),
				featured: false,
			})),
		];
		const seen = new Set<string>();
		return items.filter((item) => {
			if (seen.has(item.href)) return false;
			seen.add(item.href);
			return true;
		});
	}
	return [];
}

export function getBlogClusterLabel(postSlug: string): string {
	for (const cluster of Object.values(seoLinks.clusters)) {
		if (cluster.posts.includes(postSlug)) return cluster.label;
	}
	return 'Blog';
}

export function getRelatedBlogPosts(postSlug: string, limit = 3) {
	for (const cluster of Object.values(seoLinks.clusters)) {
		if (!cluster.posts.includes(postSlug)) continue;
		const siblings = cluster.posts.filter((s) => s !== postSlug);
		const found = siblings
			.map((s) => blogPosts.find((p) => p.slug === s))
			.filter((p): p is (typeof blogPosts)[number] => Boolean(p))
			.slice(0, limit);
		if (found.length) return found;
	}
	return blogPosts.filter((p) => p.slug !== postSlug).slice(0, limit);
}

export function getPostRelatedLinks(postSlug: string) {
	for (const cluster of Object.values(seoLinks.clusters)) {
		const links = (cluster.linksTo as Record<string, string[]>)[postSlug];
		if (links) {
			return links.map((s) => ({ href: resolveSlugUrl(s), label: resolveLinkLabel(s) }));
		}
	}
	return [];
}
