function env(name: string): string {
	const fromProcess = typeof process !== 'undefined' ? process.env[name] : undefined;
	const fromMeta = (import.meta.env as Record<string, string | undefined>)[name];
	return (fromProcess || fromMeta || '').trim();
}

export function getTurnstileSiteKey(): string {
	return env('PUBLIC_TURNSTILE_SITE_KEY');
}

export function getTurnstileSecretKey(): string {
	return env('TURNSTILE_SECRET_KEY');
}

export function isTurnstileEnabled(): boolean {
	return Boolean(getTurnstileSiteKey() && getTurnstileSecretKey());
}

export async function verifyTurnstileToken(
	token: string,
	remoteip?: string,
): Promise<{ ok: true } | { ok: false; error: string }> {
	const secret = getTurnstileSecretKey();
	if (!secret) return { ok: true };

	if (!token?.trim()) {
		return { ok: false, error: 'Please complete the security check.' };
	}

	try {
		const body = new URLSearchParams({
			secret,
			response: token.trim(),
		});
		if (remoteip && remoteip !== 'unknown') {
			body.set('remoteip', remoteip);
		}

		const res = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body,
		});
		const data = (await res.json()) as { success?: boolean; 'error-codes'?: string[] };
		if (!data.success) {
			console.warn('[hlm-turnstile] verify failed', data['error-codes']);
			return { ok: false, error: 'Security check failed. Please try again.' };
		}
		return { ok: true };
	} catch (err) {
		console.error('[hlm-turnstile] verify error', err);
		return { ok: false, error: 'Security check unavailable. Please try again.' };
	}
}
