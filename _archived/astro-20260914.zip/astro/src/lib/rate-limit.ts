type Bucket = Map<string, number[]>;

const buckets = new Map<string, Bucket>();

/**
 * Sliding-window rate limiter (in-memory, per process).
 * Returns true when the key should be blocked.
 */
export function isRateLimited(
	namespace: string,
	key: string,
	maxHits: number,
	windowMs: number,
): boolean {
	let bucket = buckets.get(namespace);
	if (!bucket) {
		bucket = new Map();
		buckets.set(namespace, bucket);
	}

	const now = Date.now();
	const hits = (bucket.get(key) || []).filter((t) => now - t < windowMs);
	if (hits.length >= maxHits) {
		bucket.set(key, hits);
		return true;
	}
	hits.push(now);
	bucket.set(key, hits);
	return false;
}
