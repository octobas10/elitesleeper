function env(name: string): string {
	const fromProcess = typeof process !== 'undefined' ? process.env[name] : undefined;
	const fromMeta = (import.meta.env as Record<string, string | undefined>)[name];
	return (fromProcess || fromMeta || '').trim();
}

/** Comma-separated IPs. Empty = allow all. Supports exact IPv4/IPv6 and trailing * wildcards (e.g. 203.0.113.*). */
export function getAdminAllowedIps(): string[] {
	const raw = env('ADMIN_ALLOWED_IPS');
	if (!raw) return [];
	return raw
		.split(',')
		.map((s) => s.trim())
		.filter(Boolean);
}

export function isAdminIpAllowed(ip: string): boolean {
	const allowlist = getAdminAllowedIps();
	if (allowlist.length === 0) return true;
	if (!ip || ip === 'unknown') return false;

	const normalized = ip.replace(/^::ffff:/, '');

	return allowlist.some((entry) => {
		const rule = entry.replace(/^::ffff:/, '');
		if (rule.endsWith('.*')) {
			const prefix = rule.slice(0, -1); // keep trailing dot of "1.2.3."
			return normalized.startsWith(prefix);
		}
		if (rule.endsWith('*') && rule.includes(':')) {
			// IPv6 prefix like 2001:db8:*
			const prefix = rule.slice(0, -1);
			return normalized.startsWith(prefix);
		}
		return normalized === rule || ip === entry;
	});
}

export function adminIpBlockedResponse(isApi: boolean): Response {
	if (isApi) {
		return new Response(JSON.stringify({ error: 'Forbidden from this IP' }), {
			status: 403,
			headers: { 'Content-Type': 'application/json' },
		});
	}
	return new Response('Forbidden from this IP', {
		status: 403,
		headers: { 'Content-Type': 'text/plain; charset=utf-8' },
	});
}
