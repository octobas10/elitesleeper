import institutionData from '../data/institution-data.json';

type InstitutionJson = {
	institutions: Record<string, string>;
	campus: Record<string, Record<string, string>>;
	programs: Record<string, Record<string, Record<string, string>>>;
};

const data = institutionData as InstitutionJson;

export function getInstitutions() {
	return data.institutions;
}

export function getCampusData() {
	return data.campus;
}

export function getProgramData() {
	return data.programs;
}

export function isValidCampus(category: string, campus: string) {
	return Boolean(data.campus[category]?.[campus]);
}

export function isValidProgram(category: string, campus: string, program: string) {
	return Boolean(data.programs[category]?.[campus]?.[program]);
}
