const COOKIE_NAME = 'hlm_admin';
const TOKEN_PREFIX = 'hlm-admin-v1:';

export function getAdminPassword(): string {
	// Prefer process.env so Docker/runtime secrets work (import.meta.env is build-time).
	const fromProcess = typeof process !== 'undefined' ? process.env.ADMIN_PASSWORD : undefined;
	const fromMeta = import.meta.env.ADMIN_PASSWORD as string | undefined;
	return (fromProcess || fromMeta || '').trim();
}

export function isAdminConfigured(): boolean {
	return getAdminPassword().length > 0;
}

async function sha256Hex(value: string): Promise<string> {
	const data = new TextEncoder().encode(value);
	const digest = await crypto.subtle.digest('SHA-256', data);
	return Array.from(new Uint8Array(digest))
		.map((b) => b.toString(16).padStart(2, '0'))
		.join('');
}

export async function createAdminSessionToken(password = getAdminPassword()): Promise<string> {
	if (!password) return '';
	return sha256Hex(`${TOKEN_PREFIX}${password}`);
}

function timingSafeEqual(a: string, b: string): boolean {
	if (a.length !== b.length) return false;
	let mismatch = 0;
	for (let i = 0; i < a.length; i++) {
		mismatch |= a.charCodeAt(i) ^ b.charCodeAt(i);
	}
	return mismatch === 0;
}

export async function verifyAdminPassword(password: string): Promise<boolean> {
	const expected = getAdminPassword();
	if (!expected || !password) return false;
	return timingSafeEqual(password, expected);
}

export async function isValidAdminSession(cookieHeader: string | null): Promise<boolean> {
	if (!isAdminConfigured() || !cookieHeader) return false;
	const match = cookieHeader.match(new RegExp(`(?:^|;\\s*)${COOKIE_NAME}=([^;]+)`));
	const token = match?.[1] ? decodeURIComponent(match[1]) : '';
	if (!token) return false;
	const expected = await createAdminSessionToken();
	return timingSafeEqual(token, expected);
}

export function adminSessionCookie(token: string): string {
	const secure = import.meta.env.PROD ? '; Secure' : '';
	return `${COOKIE_NAME}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800${secure}`;
}

export function clearAdminSessionCookie(): string {
	const secure = import.meta.env.PROD ? '; Secure' : '';
	return `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`;
}

export { COOKIE_NAME };
