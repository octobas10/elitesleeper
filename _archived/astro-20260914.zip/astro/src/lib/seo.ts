import seoData from '../data/seo.json';
import { site } from '../data/site';

export type SeoSlug = keyof typeof seoData.pages;

export function getPageSeo(slug: string) {
	return (
		seoData.pages[slug as SeoSlug] ?? {
			title: site.name,
			description: site.description,
		}
	);
}

export function getPageFaqs(slug: string) {
	return seoData.faqs[slug as keyof typeof seoData.faqs] ?? [];
}

export function getPageIntro(slug: string) {
	return seoData.intros[slug as keyof typeof seoData.intros] ?? '';
}

export const organizationSchema = {
	'@context': 'https://schema.org',
	'@type': 'Organization',
	name: 'Higher Learning Marketers',
	legalName: 'Higher Learning Marketers',
	url: site.url,
	logo: `${site.url}${site.logo}`,
	description: site.description,
	email: 'support@higherlearningmarketers.com',
	telephone: '+1-718-655-2573',
	address: {
		'@type': 'PostalAddress',
		streetAddress: '138-07 82nd Drive',
		addressLocality: 'Briarwood',
		addressRegion: 'NY',
		postalCode: '11435',
		addressCountry: 'US',
	},
	areaServed: 'US',
};

export function buildWebPageSchema(title: string, description: string, url: string, type = 'WebPage') {
	return {
		'@context': 'https://schema.org',
		'@type': type,
		name: title,
		description,
		url,
		isPartOf: { '@type': 'WebSite', name: site.name, url: site.url },
	};
}

export function buildFaqSchema(faqs: { question: string; answer: string }[]) {
	if (!faqs.length) return null;
	return {
		'@context': 'https://schema.org',
		'@type': 'FAQPage',
		mainEntity: faqs.map((f) => ({
			'@type': 'Question',
			name: f.question,
			acceptedAnswer: { '@type': 'Answer', text: f.answer },
		})),
	};
}

export function buildArticleSchema(opts: {
	title: string;
	description: string;
	url: string;
	datePublished: string;
	dateModified?: string;
	image?: string;
	wordCount?: number;
	keywords?: string;
}) {
	const schema: Record<string, unknown> = {
		'@context': 'https://schema.org',
		'@type': 'Article',
		headline: opts.title,
		description: opts.description,
		url: opts.url,
		mainEntityOfPage: opts.url,
		datePublished: opts.datePublished,
		dateModified: opts.dateModified ?? opts.datePublished,
		author: {
			'@type': 'Organization',
			name: site.name,
			url: site.url,
		},
		publisher: {
			'@type': 'Organization',
			name: site.name,
			url: site.url,
			logo: {
				'@type': 'ImageObject',
				url: `${site.url}${site.logo}`,
			},
		},
		isPartOf: { '@type': 'WebSite', name: site.name, url: site.url },
	};
	if (opts.image) {
		schema.image = [opts.image];
	}
	if (opts.wordCount && opts.wordCount > 0) {
		schema.wordCount = opts.wordCount;
	}
	if (opts.keywords) {
		schema.keywords = opts.keywords;
	}
	return schema;
}

export function buildBreadcrumbSchema(items: { name: string; url?: string }[]) {
	if (items.length < 2) return null;
	return {
		'@context': 'https://schema.org',
		'@type': 'BreadcrumbList',
		itemListElement: items.map((item, index) => ({
			'@type': 'ListItem',
			position: index + 1,
			name: item.name,
			...(item.url ? { item: item.url } : {}),
		})),
	};
}

export function canonicalUrl(path: string) {
	const base = site.url.replace(/\/$/, '');
	const p = path.startsWith('/') ? path : `/${path}`;
	return `${base}${p}`;
}

export function countWordsFromHtml(html: string): number {
	const text = html
		.replace(/<script[\s\S]*?<\/script>/gi, ' ')
		.replace(/<style[\s\S]*?<\/style>/gi, ' ')
		.replace(/<[^>]+>/g, ' ')
		.replace(/&nbsp;/g, ' ')
		.replace(/\s+/g, ' ')
		.trim();
	if (!text) return 0;
	return text.split(/\s+/).filter(Boolean).length;
}
