import { isValidCampus, isValidProgram } from './institution';

export function digitsOnly(v: string) {
	return v.replace(/\D/g, '');
}

export function isEmail(v: string) {
	return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}

export function isValidName(v: string) {
	return v.trim().length >= 2;
}

export function isValidZip(v: string) {
	const zip = v.trim();
	return /^\d{5}(-\d{4})?$/.test(zip) || /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/.test(zip);
}

const studentRequired = [
	'first_name',
	'last_name',
	'email',
	'phone',
	'address',
	'city',
	'state',
	'zip',
	'category',
	'campus',
	'program_of_interest',
	'education_level',
	'desired_degree',
	'grad_year',
] as const;

const universityRequired = [
	'institution_name',
	'first_name',
	'last_name',
	'email',
	'phone',
] as const;

export function validateLead(formType: string, data: Record<string, string>) {
	if (!['student', 'university'].includes(formType)) {
		return { ok: false as const, error: 'Invalid form type.' };
	}

	const required = formType === 'student' ? studentRequired : universityRequired;
	const missing: string[] = [];

	for (const field of required) {
		if (!data[field]?.trim()) missing.push(field);
	}

	if (formType === 'student' && !data.tcpa_consent) {
		missing.push('tcpa_consent');
	}

	if (missing.length) {
		return { ok: false as const, error: 'Please fill in all required fields.', fields: missing };
	}

	if (!isEmail(data.email)) {
		return { ok: false as const, error: 'Please enter a valid email address.' };
	}

	const phone = digitsOnly(data.phone);
	if (phone.length !== 10) {
		return { ok: false as const, error: 'Please enter a valid 10-digit phone number.' };
	}

	if (data.state && !/^[A-Za-z]{2}$/.test(data.state)) {
		return { ok: false as const, error: 'Please select a valid state or province.' };
	}

	if (data.zip && !isValidZip(data.zip)) {
		return { ok: false as const, error: 'Please enter a valid ZIP or postal code.' };
	}

	for (const nameField of ['first_name', 'last_name', 'institution_name'] as const) {
		if (data[nameField] && !isValidName(data[nameField])) {
			return { ok: false as const, error: 'Please enter a valid name (at least 2 characters).' };
		}
	}

	if (data.website && !/^https?:\/\/.+/i.test(data.website)) {
		return { ok: false as const, error: 'Please enter a valid website URL.' };
	}

	if (formType === 'student') {
		const { category, campus, program_of_interest: program } = data;
		if (category && campus && !isValidCampus(category, campus)) {
			return { ok: false as const, error: 'Please select a valid campus.' };
		}
		if (category && campus && program && !isValidProgram(category, campus, program)) {
			return { ok: false as const, error: 'Please select a valid program.' };
		}
	}

	return { ok: true as const };
}
