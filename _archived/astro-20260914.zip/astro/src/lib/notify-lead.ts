function formatLeadBody(formType: string, data: Record<string, string>) {
	const lines = Object.entries(data)
		.filter(([k]) => !k.startsWith('hlm_'))
		.map(([k, v]) => `${k}: ${v}`);
	return `New ${formType} lead from Higher Learning Marketers\n\n${lines.join('\n')}`;
}

export async function notifyLead(formType: string, data: Record<string, string>) {
	const webhook = import.meta.env.LEAD_WEBHOOK_URL;
	if (webhook) {
		await fetch(webhook, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ form_type: formType, submitted_at: new Date().toISOString(), ...data }),
		});
	}

	const resendKey = import.meta.env.RESEND_API_KEY;
	const to = import.meta.env.LEAD_NOTIFY_EMAIL;
	const from = import.meta.env.LEAD_NOTIFY_FROM || 'HLM Leads <leads@higherlearningmarketers.com>';

	if (resendKey && to) {
		const res = await fetch('https://api.resend.com/emails', {
			method: 'POST',
			headers: {
				Authorization: `Bearer ${resendKey}`,
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
				from,
				to: [to],
				subject: `New ${formType} lead — ${data.email || data.institution_name || 'HLM'}`,
				text: formatLeadBody(formType, data),
			}),
		});
		if (!res.ok) {
			throw new Error(`Resend failed: ${res.status}`);
		}
		return;
	}

	const host = import.meta.env.SMTP_HOST;
	if (host && to && typeof process !== 'undefined' && process.versions?.node) {
		const nodemailer = await import('nodemailer');
		const transporter = nodemailer.default.createTransport({
			host,
			port: Number(import.meta.env.SMTP_PORT || 587),
			secure: import.meta.env.SMTP_SECURE === 'true',
			auth: {
				user: import.meta.env.SMTP_USER,
				pass: import.meta.env.SMTP_PASS,
			},
		});
		await transporter.sendMail({
			from: import.meta.env.SMTP_FROM || from,
			to,
			subject: `New ${formType} lead — ${data.email || data.institution_name || 'HLM'}`,
			text: formatLeadBody(formType, data),
		});
	}
}
