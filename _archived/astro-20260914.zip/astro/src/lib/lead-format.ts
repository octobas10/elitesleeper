import { getCampusData, getInstitutions, getProgramData } from './institution';
import type { LeadRow } from './lead-storage';

const EDUCATION_LEVELS: Record<string, string> = {
	'1': 'GED',
	'2': 'High School',
	'3': 'Some College (1–23 credits)',
	'4': 'Some College (24–47 credits)',
	'5': 'Some College (48+ credits)',
	'6': 'Associate Degree',
	'7': "Bachelor's Degree",
	'8': "Master's Degree",
	'9': 'Doctorate',
};

const DESIRED_DEGREES: Record<string, string> = {
	'1': 'Diploma',
	'2': 'Associate',
	'3': "Bachelor's",
	'4': "Master's",
	'5': 'Doctorate',
	'6': 'Certificate',
};

const FIELD_LABELS: Record<string, string> = {
	id: 'Lead ID',
	form_type: 'Form type',
	submitted_at: 'Submitted at',
	status: 'Status',
	first_name: 'First name',
	last_name: 'Last name',
	email: 'Email',
	phone: 'Phone',
	address: 'Address',
	city: 'City',
	state: 'State',
	zip: 'ZIP / postal',
	grad_year: 'HS graduation year',
	education_level: 'Highest education',
	desired_degree: 'Desired degree',
	category: 'Institution',
	campus: 'Campus',
	program_of_interest: 'Program',
	institution_name: 'Institution name',
	website: 'Website',
	job_title: 'Job title',
	message: 'Message',
	tcpa_consent: 'TCPA consent',
	tcpa_text: 'TCPA text',
	trustedformcerturl: 'TrustedForm cert URL',
	universal_leadid: 'Universal Lead ID',
	page_url: 'Page URL',
	ip: 'IP address',
	created_at: 'Created at',
};

export type LeadDetailField = {
	key: string;
	label: string;
	value: string;
	href?: string;
	code?: string;
};

export type LeadDetailSection = {
	id: string;
	title: string;
	fields: LeadDetailField[];
};

function parsePayload(lead: LeadRow): Record<string, string> {
	try {
		const parsed = JSON.parse(lead.payload) as Record<string, unknown>;
		const out: Record<string, string> = {};
		for (const [k, v] of Object.entries(parsed)) {
			if (v == null) continue;
			out[k] = String(v);
		}
		return out;
	} catch {
		return {};
	}
}

function resolveInstitution(code: string) {
	return getInstitutions()[code] || code;
}

function resolveCampus(category: string, campus: string) {
	return getCampusData()[category]?.[campus] || campus;
}

function resolveProgram(category: string, campus: string, program: string) {
	return getProgramData()[category]?.[campus]?.[program] || program;
}

function field(key: string, value: string | undefined, extras?: Partial<LeadDetailField>): LeadDetailField | null {
	const trimmed = (value ?? '').trim();
	if (!trimmed) return null;
	return {
		key,
		label: FIELD_LABELS[key] || key.replace(/_/g, ' '),
		value: trimmed,
		...extras,
	};
}

function yesNo(value: string | undefined) {
	if (!value) return '';
	if (value === '1' || value.toLowerCase() === 'true' || value.toLowerCase() === 'yes') return 'Yes';
	if (value === '0' || value.toLowerCase() === 'false' || value.toLowerCase() === 'no') return 'No';
	return value;
}

export function formatWhen(iso: string) {
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return iso;
	return d.toLocaleString(undefined, {
		year: 'numeric',
		month: 'short',
		day: 'numeric',
		hour: 'numeric',
		minute: '2-digit',
		second: '2-digit',
	});
}

export function displayName(lead: Pick<LeadRow, 'first_name' | 'last_name'>) {
	return `${lead.first_name} ${lead.last_name}`.trim() || '—';
}

export function leadSummary(lead: LeadRow) {
	const data = { ...parsePayload(lead), ...lead };
	const category = data.category || '';
	const campus = data.campus || '';
	const program = data.program_of_interest || '';

	return {
		name: displayName(lead),
		when: formatWhen(lead.created_at),
		email: lead.email,
		phone: lead.phone,
		location: [lead.city, lead.state, lead.zip].filter(Boolean).join(', '),
		address: data.address || '',
		institution:
			lead.form_type === 'university'
				? lead.institution_name || data.institution_name || ''
				: category
					? resolveInstitution(category)
					: '',
		campus: category && campus ? resolveCampus(category, campus) : campus,
		program: category && campus && program ? resolveProgram(category, campus, program) : program,
		education: EDUCATION_LEVELS[data.education_level || ''] || data.education_level || '',
		desiredDegree: DESIRED_DEGREES[data.desired_degree || ''] || data.desired_degree || '',
		gradYear: data.grad_year || '',
	};
}

export function buildLeadDetail(lead: LeadRow): {
	sections: LeadDetailSection[];
	payloadPretty: string;
	summary: ReturnType<typeof leadSummary>;
	raw: Record<string, string>;
} {
	const raw = {
		...parsePayload(lead),
		id: lead.id,
		form_type: lead.form_type,
		status: lead.status,
		first_name: lead.first_name,
		last_name: lead.last_name,
		email: lead.email,
		phone: lead.phone,
		city: lead.city,
		state: lead.state,
		zip: lead.zip,
		category: lead.category,
		campus: lead.campus,
		program_of_interest: lead.program_of_interest,
		institution_name: lead.institution_name,
		created_at: lead.created_at,
		submitted_at: parsePayload(lead).submitted_at || lead.created_at,
	};

	const category = raw.category || '';
	const campus = raw.campus || '';
	const program = raw.program_of_interest || '';

	const contact: LeadDetailField[] = [
		field('first_name', raw.first_name),
		field('last_name', raw.last_name),
		field('email', raw.email, raw.email ? { href: `mailto:${raw.email}` } : undefined),
		field('phone', raw.phone, raw.phone ? { href: `tel:${raw.phone.replace(/\D/g, '')}` } : undefined),
		field('address', raw.address),
		field('city', raw.city),
		field('state', raw.state),
		field('zip', raw.zip),
	].filter(Boolean) as LeadDetailField[];

	const education: LeadDetailField[] = [
		field('grad_year', raw.grad_year),
		field('education_level', EDUCATION_LEVELS[raw.education_level || ''] || raw.education_level, {
			code: raw.education_level,
		}),
		field('desired_degree', DESIRED_DEGREES[raw.desired_degree || ''] || raw.desired_degree, {
			code: raw.desired_degree,
		}),
	].filter(Boolean) as LeadDetailField[];

	const programFields: LeadDetailField[] = [
		field('category', resolveInstitution(category) || category, category ? { code: category } : undefined),
		field('campus', resolveCampus(category, campus) || campus, campus ? { code: campus } : undefined),
		field(
			'program_of_interest',
			resolveProgram(category, campus, program) || program,
			program ? { code: program } : undefined,
		),
	].filter(Boolean) as LeadDetailField[];

	const university: LeadDetailField[] = [
		field('institution_name', raw.institution_name),
		field('website', raw.website, raw.website ? { href: raw.website } : undefined),
		field('job_title', raw.job_title),
		field('message', raw.message),
	].filter(Boolean) as LeadDetailField[];

	const consent: LeadDetailField[] = [
		field('tcpa_consent', yesNo(raw.tcpa_consent)),
		field('tcpa_text', raw.tcpa_text),
		field(
			'trustedformcerturl',
			raw.trustedformcerturl,
			raw.trustedformcerturl ? { href: raw.trustedformcerturl } : undefined,
		),
		field('universal_leadid', raw.universal_leadid),
	].filter(Boolean) as LeadDetailField[];

	const meta: LeadDetailField[] = [
		field('id', raw.id),
		field('form_type', raw.form_type),
		field('status', raw.status),
		field('submitted_at', formatWhen(raw.submitted_at || raw.created_at)),
		field('created_at', formatWhen(raw.created_at)),
		field('page_url', raw.page_url, raw.page_url ? { href: raw.page_url } : undefined),
		field('ip', raw.ip),
	].filter(Boolean) as LeadDetailField[];

	const known = new Set([
		'id',
		'form_type',
		'status',
		'first_name',
		'last_name',
		'email',
		'phone',
		'address',
		'city',
		'state',
		'zip',
		'grad_year',
		'education_level',
		'desired_degree',
		'category',
		'campus',
		'program_of_interest',
		'institution_name',
		'website',
		'job_title',
		'message',
		'tcpa_consent',
		'tcpa_text',
		'trustedformcerturl',
		'universal_leadid',
		'page_url',
		'ip',
		'submitted_at',
		'created_at',
		'payload',
	]);

	const other: LeadDetailField[] = Object.entries(raw)
		.filter(([key, value]) => !known.has(key) && String(value).trim())
		.map(([key, value]) => field(key, value)!)
		.filter(Boolean);

	const sections: LeadDetailSection[] = [
		{ id: 'contact', title: 'Contact', fields: contact },
	];

	if (lead.form_type === 'university') {
		if (university.length) sections.push({ id: 'university', title: 'University / partnership', fields: university });
	} else {
		if (education.length) sections.push({ id: 'education', title: 'Education background', fields: education });
		if (programFields.length) sections.push({ id: 'program', title: 'Program interest', fields: programFields });
	}

	if (consent.length) sections.push({ id: 'consent', title: 'Consent & compliance', fields: consent });
	sections.push({ id: 'meta', title: 'Submission meta', fields: meta });
	if (other.length) sections.push({ id: 'other', title: 'Other fields', fields: other });

	return {
		sections,
		payloadPretty: JSON.stringify(raw, null, 2),
		summary: leadSummary(lead),
		raw,
	};
}
