# Security

HLM runs as an Astro/Node app (often Docker). App-level checks help; **Cloudflare in front of the whole site** is what stops real DDoS and most edge junk.

## Layers

| Layer | What it covers | How |
|-------|----------------|-----|
| Cloudflare proxy (orange cloud) | DDoS, caching, TLS, bot fight | DNS → Cloudflare, proxy ON |
| Cloudflare WAF | SQLi/XSS patterns, bad bots | Security → WAF rules |
| Turnstile | Form + admin login bots | Keys in `.env` |
| App rate limits | Burst API / login / submit | Built-in middleware |
| Admin password + session | Lead PII access | `ADMIN_PASSWORD` |
| Admin IP allowlist | Lock `/admin` to known IPs | `ADMIN_ALLOWED_IPS` |
| Security headers | Clickjacking, MIME sniffing | Middleware on every response |

Turnstile alone is **not** whole-site DDoS protection.

---

## 1. Cloudflare for the whole domain (required for DDoS)

1. Add the site in Cloudflare (Free plan is enough to start).
2. Point your registrar nameservers to Cloudflare.
3. DNS: A/AAAA/CNAME for the site → **Proxied** (orange cloud), not DNS-only.
4. SSL/TLS mode: **Full (strict)** once the origin has a valid cert (or Cloudflare Origin cert).
5. Security → Settings:
   - Security Level: Medium (or High under attack)
   - Bot Fight Mode: On (Free)
6. Security → WAF: enable managed rules you need; add a custom rule to challenge or block `/admin*` from unknown countries if desired.
7. Under heavy attack: Security → **I'm Under Attack Mode**.

Origin (Docker/VPS) should only accept traffic from Cloudflare IPs (firewall), or at least not expose random ports publicly without a reverse proxy.

---

## 2. Turnstile (forms + admin login)

1. Cloudflare dashboard → **Turnstile** → Add widget.
2. Hostnames: production domain + `localhost` for local tests.
3. Mode: Managed.
4. Put keys in `astro/.env`:

```bash
PUBLIC_TURNSTILE_SITE_KEY=your-site-key
TURNSTILE_SECRET_KEY=your-secret-key
```

5. Restart the app.

Dummy always-pass keys (local only):

```bash
PUBLIC_TURNSTILE_SITE_KEY=1x00000000000000000000AA
TURNSTILE_SECRET_KEY=1x0000000000000000000000000000000AA
```

Leave both blank to disable Turnstile.

---

## 3. Admin panel

```bash
ADMIN_PASSWORD=long-random-password

# Optional but recommended in production — your office/VPN IPs only
ADMIN_ALLOWED_IPS=203.0.113.10,198.51.100.0.*
```

- Empty `ADMIN_ALLOWED_IPS` = any IP can reach the login page (password still required).
- Login is rate-limited: 5 attempts / 15 minutes / IP.
- Turnstile also applies to admin login when secret key is set.

---

## 4. App-level shields (already in code)

- `/api/*` burst limit (~120 req/min/IP)
- Lead submit: 5 / 15 min / IP + honeypot + Turnstile (if configured)
- Admin login: rate limit + Turnstile + password + optional IP allowlist
- Security headers on all responses
- `/admin/` and `/api/` disallowed in `robots.txt`

---

## 5. Checklist before go-live

- [ ] Domain orange-clouded on Cloudflare
- [ ] Strong `ADMIN_PASSWORD`
- [ ] `ADMIN_ALLOWED_IPS` set to your IPs
- [ ] Real Turnstile keys (not dummy) on production
- [ ] Origin firewall / only Cloudflare (or reverse proxy) reaches the app
- [ ] HTTPS end-to-end (Full strict)
