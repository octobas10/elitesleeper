# Deploy to Cloudflare Pages

This site uses the **Cloudflare adapter** (`@astrojs/cloudflare`) so forms and `/api/submit/` work on the edge.

## Option A — Deploy from your computer (fastest for demo)

### 1. Create a free Cloudflare account

https://dash.cloudflare.com/sign-up

### 2. Log in with Wrangler

```bash
cd astro
npx wrangler login
```

A browser window opens — approve access.

### 3. Set production secrets

Replace values with your real credentials:

```bash
npx wrangler pages secret put ELITE_PROMO_CODE --project-name=higherlearningmarketers
npx wrangler pages secret put LEAD_NOTIFY_EMAIL --project-name=higherlearningmarketers
npx wrangler pages secret put RESEND_API_KEY --project-name=higherlearningmarketers
# Optional:
npx wrangler pages secret put LEAD_WEBHOOK_URL --project-name=higherlearningmarketers
```

If the project does not exist yet, run `npm run deploy` first (step 4) — Wrangler creates it — then add secrets.

### 4. Deploy

```bash
npm run deploy
```

Wrangler prints a URL like:

`https://higherlearningmarketers.pages.dev`

### 5. Preview branch (optional)

```bash
npm run deploy:preview
```

Gives a preview URL for client review before going live.

---

## Option B — Connect GitHub (auto-deploy on push)

1. Push the `astro/` folder to GitHub (or the whole repo with root directory `astro`).
2. Cloudflare dashboard → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**.
3. Settings:
   - **Root directory:** `astro`
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
   - **Node version:** 22
4. **Environment variables** (Settings → Variables): copy from `.env.example`
5. Every push to `main` redeploys automatically.

---

## Point your domain (higherlearningmarketers.com)

1. Cloudflare dashboard → your Pages project → **Custom domains**
2. Add `higherlearningmarketers.com` and `www.higherlearningmarketers.com`
3. If the domain is already on Cloudflare DNS, records are added automatically.
4. Wait for SSL (usually a few minutes).

**After DNS is live:** turn off the old WordPress server on Rackspace.

---

## Environment variables reference

| Variable | Required | Purpose |
|----------|----------|---------|
| `ELITE_PROMO_CODE` | For student leads | Forwards to Elite Biz Panel |
| `LEAD_NOTIFY_EMAIL` | Recommended | Where lead emails go |
| `RESEND_API_KEY` | Recommended | Sends email via Resend |
| `LEAD_WEBHOOK_URL` | Optional | Zapier/Make webhook |
| `PUBLIC_ENABLE_TRUSTEDFORM` | Optional | `true` (default) |
| `PUBLIC_ENABLE_LEADID` | Optional | `true` (default) |

SMTP (`SMTP_HOST`, etc.) works locally with Node preview but **not** on Cloudflare Workers — use Resend or webhook in production.

---

## Optional: store leads in Cloudflare KV

1. Dashboard → **Workers & Pages** → **KV** → Create namespace `hlm-leads`
2. Copy the namespace ID into `wrangler.toml`:

```toml
[[kv_namespaces]]
binding = "LEADS_KV"
id = "YOUR_NAMESPACE_ID"
```

3. Redeploy. Leads are stored in KV when email/webhook also fire.

---

## Verify after deploy

- [ ] Home page loads
- [ ] Submit university form on `/contact-us/`
- [ ] Check email or webhook received the lead
- [ ] `/sitemap-index.xml` loads
- [ ] View source — JSON-LD present

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Form shows success but no email | Set `RESEND_API_KEY` + `LEAD_NOTIFY_EMAIL` in Cloudflare env vars |
| 404 on `/api/submit/` | Ensure you deployed with Cloudflare adapter (not static-only) |
| Old WordPress still showing | DNS still points to Rackspace — update nameservers or A record to Cloudflare |
